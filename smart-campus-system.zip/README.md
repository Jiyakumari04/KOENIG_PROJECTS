# Smart Campus Management and Navigation System

## Files
- `00_requirement_coverage.md` — maps every lab requirement to the file that implements it
- `01_hierarchy_recursion.js` — recursive exploration of the campus building hierarchy
- `02_graph.js` — campus transport network: adjacency list/matrix, BFS, DFS, connected components, shortest path
- `03_backtracking.js` — route search within a distance budget, with pruning
- `04_bst.js` — Binary Search Tree for student/facility records, traversals, height/depth
- `05_heap_priority_queue.js` — max-heap priority queue for maintenance requests
- `06_greedy_scheduling.js` — greedy maximum non-overlapping event scheduling
- `07_dynamic_programming.js` — scholarship budget allocation: recursive, memoized, tabulated
- `08_analysis.md` — concepts, comparisons, complexity, and limitations for every section
- `main.js` — runs all modules together on shared campus data

## Running
Each file can be run individually:
```
node 02_graph.js
```
Or run everything together:
```
node main.js
```
Requires Node.js (no external dependencies).
