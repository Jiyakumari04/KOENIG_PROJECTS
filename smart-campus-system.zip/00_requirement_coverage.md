# Requirement Coverage

| Lab Requirement | Where it's implemented |
|---|---|
| Recursive problem decomposition, base/recursive cases | `01_hierarchy_recursion.js` |
| Call-stack tracing and recursion-tree analysis | `01_hierarchy_recursion.js`, `08_analysis.md` §1 |
| Backtracking with pruning | `03_backtracking.js`, `08_analysis.md` §2 |
| Binary trees and Binary Search Trees | `04_bst.js` |
| Tree traversals (preorder, inorder, postorder, level-order) | `04_bst.js` |
| Node depth and tree height | `04_bst.js` (`depthOf`, `height`) |
| Heap-based priority queue | `05_heap_priority_queue.js` |
| Tree-based problem-solving pattern (heap as implicit tree) | `05_heap_priority_queue.js`, `08_analysis.md` §3 |
| Directed/undirected graphs | `02_graph.js` (`addEdge` directed override) |
| Weighted/unweighted graphs | `02_graph.js` (edge weights; unweighted BFS shortest path) |
| Adjacency matrix representation | `02_graph.js` (`toAdjacencyMatrix`) |
| Adjacency list representation | `02_graph.js` (`adjList`) |
| BFS | `02_graph.js` (`bfs`) |
| DFS | `02_graph.js` (`dfs`) |
| Connected components | `02_graph.js` (`connectedComponents`) |
| Shortest-path (weighted and unweighted) | `02_graph.js` (`shortestPathDijkstra`, `shortestPathUnweighted`) |
| Greedy-choice strategy, max non-overlapping events | `06_greedy_scheduling.js` |
| Recognising greedy-suitable problems | `08_analysis.md` §5 |
| Overlapping subproblems, optimal substructure | `07_dynamic_programming.js`, `08_analysis.md` §6 |
| Recursive solution | `07_dynamic_programming.js` (`allocateRecursive`) |
| Memoized solution | `07_dynamic_programming.js` (`allocateMemoized`) |
| Tabulated (bottom-up) solution | `07_dynamic_programming.js` (`allocateTabulated`) |
| Comparison: time, space, repeated computation, call stack | `08_analysis.md` §6 (table + measured timings) |
| Integrated system demonstration | `main.js` |
| For each technique: implement, demonstrate, explain why appropriate, compare alternatives, complexity, limitations | `08_analysis.md` covers all points per section |
