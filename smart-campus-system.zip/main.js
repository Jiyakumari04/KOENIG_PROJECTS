const { getCampusHierarchy, countRoomsAndLabs, maxDepth } = require("./01_hierarchy_recursion.js");
const { buildCampusGraph } = require("./02_graph.js");
const { findAllRoutesWithinBudget } = require("./03_backtracking.js");
const { BST } = require("./04_bst.js");
const { MaxHeap } = require("./05_heap_priority_queue.js");
const { selectMaxNonOverlappingEvents } = require("./06_greedy_scheduling.js");
const { allocateRecursive, allocateMemoized, allocateTabulated } = require("./07_dynamic_programming.js");

function section(title) {
    console.log("\n" + title);
    console.log("-".repeat(title.length));
}

section("Campus Hierarchy (Recursion)");
const campus = getCampusHierarchy();
console.log("Total rooms and labs:", countRoomsAndLabs(campus));
console.log("Hierarchy depth:", maxDepth(campus));

section("Campus Transport Graph");
const graph = buildCampusGraph();
console.log("BFS from MainGate:", graph.bfs("MainGate"));
console.log("Connected components:", graph.connectedComponents().map(c => c.join(", ")));
console.log("Shortest path MainGate -> Hostels:", graph.shortestPathDijkstra("MainGate", "Hostels"));

section("Backtracking: Routes Within Budget");
const routes = findAllRoutesWithinBudget(graph, "MainGate", "Hostels", 1200);
routes.forEach(r => console.log(` ${r.path.join(" -> ")} (${r.distance}m)`));

section("Student Records (BST)");
const tree = new BST();
[[1004, "Neha Joshi"], [1002, "Sunita Sharma"], [1007, "Vikas Singh"], [1001, "Ravi Kumar"]]
    .forEach(([id, name]) => tree.insert(id, name));
console.log("Inorder (sorted by ID):", tree.inorder());
console.log("Tree height:", tree.height());

section("Maintenance Requests (Heap)");
const heap = new MaxHeap();
[{ id: "M1", priority: 2 }, { id: "M2", priority: 5 }, { id: "M3", priority: 9 }].forEach(r => heap.insert(r));
console.log("Next to handle:", heap.extractMax());

section("Event Scheduling (Greedy)");
const events = [
    { name: "Lecture", start: 9, end: 10 },
    { name: "Exam", start: 9.5, end: 11.5 },
    { name: "Workshop", start: 10, end: 12 },
    { name: "Meeting", start: 12, end: 13 }
];
console.log(selectMaxNonOverlappingEvents(events).map(e => e.name));

section("Scholarship Allocation (Recursion vs Memoization vs Tabulation)");
const scholarships = [
    { name: "A", cost: 20, benefit: 60 },
    { name: "B", cost: 30, benefit: 100 },
    { name: "C", cost: 10, benefit: 40 }
];
console.log("Recursive:", allocateRecursive(scholarships, 40));
console.log("Memoized: ", allocateMemoized(scholarships, 40));
console.log("Tabulated:", allocateTabulated(scholarships, 40));
