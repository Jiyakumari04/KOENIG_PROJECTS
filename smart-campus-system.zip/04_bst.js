class BSTNode {
    constructor(id, data) {
        this.id = id;
        this.data = data;
        this.left = null;
        this.right = null;
    }
}

class BST {
    constructor() {
        this.root = null;
    }

    insert(id, data) {
        this.root = this._insert(this.root, id, data);
    }

    _insert(node, id, data) {
        if (!node) return new BSTNode(id, data);
        if (id < node.id) node.left = this._insert(node.left, id, data);
        else if (id > node.id) node.right = this._insert(node.right, id, data);
        return node;
    }

    search(id) {
        return this._search(this.root, id);
    }

    _search(node, id) {
        if (!node) return null;
        if (id === node.id) return node.data;
        return id < node.id ? this._search(node.left, id) : this._search(node.right, id);
    }

    delete(id) {
        this.root = this._delete(this.root, id);
    }

    _delete(node, id) {
        if (!node) return null;
        if (id < node.id) {
            node.left = this._delete(node.left, id);
        } else if (id > node.id) {
            node.right = this._delete(node.right, id);
        } else {
            if (!node.left) return node.right;
            if (!node.right) return node.left;
            let successor = node.right;
            while (successor.left) successor = successor.left;
            node.id = successor.id;
            node.data = successor.data;
            node.right = this._delete(node.right, successor.id);
        }
        return node;
    }

    preorder(node = this.root, result = []) {
        if (node) {
            result.push(node.id);
            this.preorder(node.left, result);
            this.preorder(node.right, result);
        }
        return result;
    }

    inorder(node = this.root, result = []) {
        if (node) {
            this.inorder(node.left, result);
            result.push(node.id);
            this.inorder(node.right, result);
        }
        return result;
    }

    postorder(node = this.root, result = []) {
        if (node) {
            this.postorder(node.left, result);
            this.postorder(node.right, result);
            result.push(node.id);
        }
        return result;
    }

    levelOrder() {
        if (!this.root) return [];
        const result = [];
        const queue = [this.root];
        while (queue.length) {
            const node = queue.shift();
            result.push(node.id);
            if (node.left) queue.push(node.left);
            if (node.right) queue.push(node.right);
        }
        return result;
    }

    height(node = this.root) {
        if (!node) return -1;
        return 1 + Math.max(this.height(node.left), this.height(node.right));
    }

    depthOf(id, node = this.root, depth = 0) {
        if (!node) return -1;
        if (id === node.id) return depth;
        return id < node.id
            ? this.depthOf(id, node.left, depth + 1)
            : this.depthOf(id, node.right, depth + 1);
    }
}

if (require.main === module) {
    const tree = new BST();
    const records = [
        [1004, "Neha Joshi - Cardiology"],
        [1002, "Sunita Sharma - General"],
        [1007, "Vikas Singh - Orthopedics"],
        [1001, "Ravi Kumar - Cardiology"],
        [1003, "Amit Verma - Orthopedics"],
        [1006, "Priya Nair - General"],
        [1008, "Anjali Rao - Neurology"]
    ];
    records.forEach(([id, data]) => tree.insert(id, data));

    console.log("Preorder:", tree.preorder());
    console.log("Inorder (sorted by ID):", tree.inorder());
    console.log("Postorder:", tree.postorder());
    console.log("Level-order:", tree.levelOrder());

    console.log("\nTree height:", tree.height());
    console.log("Depth of 1008:", tree.depthOf(1008));
    console.log("Depth of 1004 (root):", tree.depthOf(1004));

    console.log("\nSearch 1007:", tree.search(1007));
    console.log("Search 9999:", tree.search(9999));

    tree.delete(1002);
    console.log("\nAfter deleting 1002, inorder:", tree.inorder());
}

module.exports = { BST, BSTNode };
