function allocateRecursive(scholarships, budget, index = 0) {
    if (index >= scholarships.length || budget <= 0) return 0;

    const current = scholarships[index];
    const skip = allocateRecursive(scholarships, budget, index + 1);

    if (current.cost > budget) return skip;

    const take = current.benefit + allocateRecursive(scholarships, budget - current.cost, index + 1);
    return Math.max(take, skip);
}

function allocateMemoized(scholarships, budget) {
    const memo = new Map();

    function solve(index, remainingBudget) {
        if (index >= scholarships.length || remainingBudget <= 0) return 0;
        const key = `${index},${remainingBudget}`;
        if (memo.has(key)) return memo.get(key);

        const current = scholarships[index];
        const skip = solve(index + 1, remainingBudget);
        let result = skip;
        if (current.cost <= remainingBudget) {
            const take = current.benefit + solve(index + 1, remainingBudget - current.cost);
            result = Math.max(take, skip);
        }

        memo.set(key, result);
        return result;
    }

    return solve(0, budget);
}

function allocateTabulated(scholarships, budget) {
    const n = scholarships.length;
    const table = Array.from({ length: n + 1 }, () => new Array(budget + 1).fill(0));

    for (let i = 1; i <= n; i++) {
        const { cost, benefit } = scholarships[i - 1];
        for (let b = 0; b <= budget; b++) {
            if (cost > b) {
                table[i][b] = table[i - 1][b];
            } else {
                table[i][b] = Math.max(table[i - 1][b], benefit + table[i - 1][b - cost]);
            }
        }
    }
    return table[n][budget];
}

function timeIt(fn, ...args) {
    const start = process.hrtime.bigint();
    const result = fn(...args);
    const end = process.hrtime.bigint();
    return { result, ms: Number(end - start) / 1e6 };
}

if (require.main === module) {
    const scholarships = [
        { name: "Merit Scholarship A", cost: 20, benefit: 60 },
        { name: "Need-based Grant B", cost: 30, benefit: 100 },
        { name: "Sports Scholarship C", cost: 10, benefit: 40 },
        { name: "Research Fellowship D", cost: 40, benefit: 120 },
        { name: "Minority Scholarship E", cost: 15, benefit: 50 }
    ];
    const budget = 60;

    console.log(`Allocating a budget of ${budget} across ${scholarships.length} scholarships.\n`);

    console.log("Recursive:", allocateRecursive(scholarships, budget));
    console.log("Memoized: ", allocateMemoized(scholarships, budget));
    console.log("Tabulated:", allocateTabulated(scholarships, budget));

    const biggerSet = Array.from({ length: 22 }, (_, i) => ({
        name: `Fund ${i}`,
        cost: 5 + (i % 10),
        benefit: 10 + (i % 15) * 3
    }));
    const bigBudget = 80;

    console.log(`\nTiming comparison on ${biggerSet.length} items, budget ${bigBudget}:`);
    const rec = timeIt(allocateRecursive, biggerSet, bigBudget);
    console.log(`Recursive: result=${rec.result}, time=${rec.ms.toFixed(2)}ms`);
    const memo = timeIt(allocateMemoized, biggerSet, bigBudget);
    console.log(`Memoized:  result=${memo.result}, time=${memo.ms.toFixed(2)}ms`);
    const tab = timeIt(allocateTabulated, biggerSet, bigBudget);
    console.log(`Tabulated: result=${tab.result}, time=${tab.ms.toFixed(2)}ms`);
}

module.exports = { allocateRecursive, allocateMemoized, allocateTabulated };
