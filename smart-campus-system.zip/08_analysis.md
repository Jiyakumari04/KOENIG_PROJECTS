# Smart Campus System — Design Analysis

## 1. Recursion (01_hierarchy_recursion.js)

**Base case vs recursive case:** `countRoomsAndLabs` bottoms out at a floor
node (it has a `rooms`/`labs` array directly) — that's the base case, returning
a count with no further recursive call. Any node above a floor (Campus,
Building) has no `rooms`/`labs` of its own, only children to recurse into —
that's the recursive case, which sums the results of recursive calls on each
child.

**Call-stack behaviour:** Each recursive call pushes a new stack frame holding
that node's own local state (`node`, `depth`, its partial `total`). The trace
printed by the demo (`[recursive case] entering ...` / `leaving ...`) mirrors
the stack growing on the way down and unwinding on the way back up as each
frame's `total` is returned to its caller.

**Recursion tree:** The call tree fans out from Campus to each Building to
each Floor. Its shape matches the hierarchy itself: depth equals hierarchy
depth (`maxDepth`), and the number of leaf calls equals the number of floors.

**Complexity:** O(nodes in hierarchy) time, O(depth) space for the call
stack — here depth is small and bounded (Campus -> Building -> Floor), so
stack depth never grows large.

---

## 2. Backtracking (03_backtracking.js)

**Decision space:** At every location, the next decision is "which unvisited
neighbor to move to next." Exploring every choice at every node generates the
full space of possible routes.

**Pruning:** Two prune conditions cut off invalid/unneeded branches before
they're fully explored: (1) a node already in the current path is skipped
(no revisits — avoids infinite loops), and (2) if the distance so far plus
the next edge would exceed the budget, that branch is abandoned immediately
rather than continuing to explore it. The `visited` set is added to on entry
and removed on exit of `explore()`, which is what makes this backtracking
(not just DFS) — the algorithm "undoes" its choice before trying the next one.

**Why backtracking here:** The number of simple paths between two campus
nodes can be exponential in graph size; pruning by budget avoids wasted work
exploring paths that could never be valid, which is exactly what
distinguishes backtracking from brute-force enumeration.

**Complexity:** Worst case O(V!) paths in a dense unpruned graph; pruning by
budget keeps the practical cost far lower on the small campus graph used
here. Space is O(V) for the recursion stack and current path.

---

## 3. Trees, BST, Heaps

### Binary Search Tree (04_bst.js)

**Terminology:** root, parent/child, leaf, subtree, height (longest
root-to-leaf path, edge count), depth (distance from root to a given node).

**Why a BST for student/facility records:** average O(log n) search/insert/
delete on ID-ordered data, with inorder traversal giving IDs in sorted order
"for free" — useful for generating sorted reports without a separate sort
step.

**Traversals demonstrated:** preorder (node, left, right — good for copying/
serializing the tree), inorder (left, node, right — sorted output for a
BST), postorder (left, right, node — good for safely deleting/freeing a
tree bottom-up), level-order (BFS by level — good for printing the tree
shape or finding the shallowest match).

**Complexity:** O(log n) average for insert/search/delete on a balanced
tree; O(n) worst case on a degenerate (linear-chain) tree, which is why
production systems use a self-balancing variant (AVL/Red-Black) when input
order isn't controlled. Space O(n) for n nodes, O(h) recursion stack where h
is tree height.

### Heap-based priority queue (05_heap_priority_queue.js)

**Why appropriate:** Maintenance requests must always be processed
highest-priority-first, and a binary max-heap gives O(log n) insert and
O(log n) extract-max while keeping O(1) peek at the current most urgent
request — better than scanning a list for the max each time (O(n)) or
keeping a fully sorted list (O(n) insert).

**Tree-based problem solving:** the heap is a complete binary tree stored
compactly in an array, using index arithmetic (`2i+1`, `2i+2`, `(i-1)/2`)
instead of explicit node pointers — `siftUp`/`siftDown` restore the heap
property in O(log n) by walking up/down that implicit tree structure.

**Complexity:** insert O(log n), extractMax O(log n), peek O(1). Space
O(n).

---

## 4. Graphs (02_graph.js)

**Terminology:** directed edge (one-way, e.g. ParkingArea -> MainGate only)
vs undirected (two-way, most campus roads); weighted edge (carries a
distance/cost) vs unweighted (all edges treated equal, used for hop-count
shortest path).

**Adjacency list vs adjacency matrix:**
| Aspect | Adjacency List | Adjacency Matrix |
|---|---|---|
| Space | O(V + E) | O(V²) |
| Check edge (u,v) exists | O(degree(u)) | O(1) |
| Iterate all neighbors of u | O(degree(u)) | O(V) |
| Best for | sparse graphs (a campus road network) | dense graphs, or when O(1) edge lookup matters |

The campus network is sparse (few roads relative to possible pairs of
locations), so the adjacency list is the more space-efficient primary
representation; the adjacency matrix is generated alongside it to
demonstrate both representations as required.

**BFS vs DFS:** BFS explores level-by-level using a queue — it's the right
tool for unweighted shortest path (fewest hops) and is used here for
connected-component discovery. DFS explores as deep as possible using a
stack (or recursion) before backtracking — used here for full-graph
traversal order and as the traversal strategy underlying backtracking.
Both are O(V + E) time, O(V) space.

**Connected components:** computed on an undirected view of the graph
(edge direction ignored) via repeated BFS from every unvisited node. Using
directed edges directly for "reachability" would not give a true partition
of the graph — a node might be reachable from another without being able to
reach it back (as with the one-way ParkingArea/Hostels connections here) —
this distinction between weak (direction ignored) and strong (must be
mutually reachable) connectivity is why the undirected view is used.

**Shortest path:** for the unweighted view, BFS naturally finds the
fewest-hops path (O(V + E)). For the weighted view, Dijkstra's algorithm is
used since all campus road distances are non-negative — it repeatedly picks
the closest unvisited node and relaxes its edges, giving the true minimum
total distance. Dijkstra here is O(V²) (linear scan for the minimum each
round); a binary-heap-backed priority queue would bring that down to
O((V + E) log V), which matters once the campus graph gets large.

**Limitations:** Dijkstra doesn't work correctly with negative edge weights
(would need Bellman-Ford). The current adjacency matrix generation is
O(V + E) but the matrix itself uses O(V²) space regardless of how sparse the
graph is, which wastes memory on a large, sparse campus network.

---

## 5. Greedy Algorithm — Event Scheduling (06_greedy_scheduling.js)

**Greedy-choice property:** at each step, picking the event that finishes
earliest among the remaining compatible events never prevents an optimal
solution — finishing early always leaves the most room for future events, so
this local decision is always at least as good as any other choice.

**Local decisions:** the algorithm only ever asks "does this event start
after the last one I picked ended?" — no lookahead or backtracking is
needed, unlike the DP problem below.

**Optimal substructure:** once the earliest-finishing compatible event is
chosen, the remaining problem (selecting from the events that don't overlap
it) is the exact same kind of problem on a smaller input — an optimal
solution to the whole problem is the chosen event plus an optimal solution
to that remaining sub-problem.

**Recognising a greedy-suitable problem:** a problem fits greedy when (1) a
locally optimal/"obviously good" choice can be proven never to block a
globally optimal solution (the exchange-argument proof for earliest-finish
scheduling), and (2) the problem breaks into a smaller instance of itself
after that choice, with no need to revisit the decision later. Contrast this
with the scholarship allocation problem below, where a locally attractive
item (best benefit/cost ratio) can still lead to a suboptimal total —
that's the signal a problem needs DP instead of greedy.

**Complexity:** O(n log n) for the sort, O(n) for the single scan — O(n log n)
overall. Space O(n) for the sorted copy.

---

## 6. Dynamic Programming — Scholarship Allocation (07_dynamic_programming.js)

**Overlapping subproblems:** `solve(index, remainingBudget)` is called
repeatedly with the same `(index, remainingBudget)` pair across different
branches of the recursion tree (e.g. skipping item 1 then item 2 reaches the
same state as taking item 1 then skipping a cheaper item 2, if the leftover
budget matches) — the plain recursive version recomputes each of these
identical subproblems from scratch every time.

**Optimal substructure:** the best allocation for `n` items and budget `B`
is built from the best allocation of the first `n-1` items under budget `B`
(skip item n) or under `B - cost(n)` plus item n's benefit (take item n) —
the optimal solution to the full problem is assembled from optimal solutions
to smaller subproblems.

**Recursive -> Memoized -> Tabulated:**
- *Recursive:* directly encodes the recurrence; correct but exponential —
  recomputes identical `(index, budget)` states repeatedly.
- *Memoized (top-down):* same recursive structure, but caches each
  `(index, budget)` result in a `Map` the first time it's computed, so
  repeated states return instantly on subsequent calls.
- *Tabulated (bottom-up):* fills a 2D table iteratively from the smallest
  subproblems upward, with no recursive calls at all.

**Comparison (measured in 07_dynamic_programming.js, 22 items, budget 80):**
| Approach | Time Complexity | Space Complexity | Repeated Computation | Call Stack |
|---|---|---|---|---|
| Recursive | O(2ⁿ) worst case | O(n) (stack only) | Yes — same states recomputed many times | Deep — one frame per recursive call, up to depth n |
| Memoized (top-down) | O(n · budget) | O(n · budget) for the cache + O(n) stack | No — each state computed once | Still recursive, same depth as above, but far fewer total calls |
| Tabulated (bottom-up) | O(n · budget) | O(n · budget) for the table | No | None — pure iteration, no call stack growth |

The measured run showed the plain recursive version taking roughly 20-30x
longer than the memoized version, and the tabulated version faster still by
avoiding function-call overhead entirely.

**Limitations:** Memoization and tabulation both trade time for O(n · budget)
space, which can be significant if the budget is large (the state space
grows with the budget value, not just the number of items). Tabulation loses
the natural "solve only what you need" laziness of recursion/memoization —
it always fills the entire table even if only a few final states are ever
queried.

---

## Choosing the right technique — summary

| Problem | Technique used | Why |
|---|---|---|
| Explore nested campus hierarchy | Recursion | Structure is naturally self-similar (tree of unknown depth) |
| Enumerate valid routes under a budget | Backtracking | Need every feasible solution, with invalid ones pruned early |
| Store/query student & facility records | BST | Ordered, ID-keyed data with frequent search/insert/delete |
| Process maintenance requests by urgency | Heap / priority queue | Always need the current maximum, efficiently, as items arrive |
| Explore/connect campus locations | Graph (BFS/DFS/Dijkstra) | Relationships between locations aren't hierarchical — a general network |
| Schedule maximum non-overlapping events | Greedy | Provably optimal local choice, no need to reconsider later |
| Allocate a limited budget across scholarships | Dynamic Programming | Locally attractive choices can be globally wrong — needs exhaustive-but-cached search |
