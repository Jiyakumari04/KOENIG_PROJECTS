function getCampusHierarchy() {
    return {
        name: "Campus",
        buildings: [
            {
                name: "Engineering Block",
                floors: [
                    { name: "Ground Floor", rooms: ["Room 101", "Room 102"], labs: ["Networking Lab"] },
                    { name: "First Floor", rooms: ["Room 201"], labs: ["Robotics Lab", "AI Lab"] }
                ]
            },
            {
                name: "Science Block",
                floors: [
                    { name: "Ground Floor", rooms: ["Room 301"], labs: ["Chemistry Lab", "Physics Lab"] },
                    { name: "First Floor", rooms: ["Room 401", "Room 402", "Room 403"], labs: [] }
                ]
            },
            {
                name: "Library",
                floors: [
                    { name: "Ground Floor", rooms: ["Reading Hall"], labs: [] },
                    { name: "First Floor", rooms: ["Reference Section", "Digital Archive"], labs: [] }
                ]
            }
        ]
    };
}

function countRoomsAndLabs(node, depth = 0) {
    const indent = "  ".repeat(depth);

    if (Array.isArray(node.rooms) || Array.isArray(node.labs)) {
        const count = (node.rooms ? node.rooms.length : 0) + (node.labs ? node.labs.length : 0);
        console.log(`${indent}[base case] ${node.name}: ${count} spaces`);
        return count;
    }

    console.log(`${indent}[recursive case] entering ${node.name}`);
    const children = node.buildings || node.floors;
    let total = 0;
    for (const child of children) {
        total += countRoomsAndLabs(child, depth + 1);
    }
    console.log(`${indent}[recursive case] leaving ${node.name}: ${total} spaces total`);
    return total;
}

function maxDepth(node, depth = 0) {
    const children = node.buildings || node.floors;
    if (!children) return depth;
    let deepest = depth;
    for (const child of children) {
        deepest = Math.max(deepest, maxDepth(child, depth + 1));
    }
    return deepest;
}

function findRoomOrLab(node, targetName) {
    if (node.rooms && node.rooms.includes(targetName)) return `${node.name} (room)`;
    if (node.labs && node.labs.includes(targetName)) return `${node.name} (lab)`;
    const children = node.buildings || node.floors;
    if (!children) return null;
    for (const child of children) {
        const found = findRoomOrLab(child, targetName);
        if (found) return `${node.name} -> ${found}`;
    }
    return null;
}

if (require.main === module) {
    const campus = getCampusHierarchy();

    console.log("Recursion trace (base case vs recursive case):");
    const total = countRoomsAndLabs(campus);
    console.log(`\nTotal rooms and labs on campus: ${total}`);

    console.log(`\nMaximum hierarchy depth: ${maxDepth(campus)}`);

    console.log("\nLocating 'AI Lab':", findRoomOrLab(campus, "AI Lab"));
    console.log("Locating 'Room 999':", findRoomOrLab(campus, "Room 999"));
}

module.exports = { getCampusHierarchy, countRoomsAndLabs, maxDepth, findRoomOrLab };
