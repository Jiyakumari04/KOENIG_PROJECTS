class Graph {
    constructor(directed = false) {
        this.directed = directed;
        this.adjList = new Map();
    }

    addNode(node) {
        if (!this.adjList.has(node)) this.adjList.set(node, []);
    }

    addEdge(u, v, weight = 1, directedOverride = null) {
        this.addNode(u);
        this.addNode(v);
        this.adjList.get(u).push({ node: v, weight });
        const isDirected = directedOverride !== null ? directedOverride : this.directed;
        if (!isDirected) {
            this.adjList.get(v).push({ node: u, weight });
        }
    }

    nodes() {
        return [...this.adjList.keys()];
    }

    toAdjacencyMatrix() {
        const nodeList = this.nodes();
        const index = new Map(nodeList.map((n, i) => [n, i]));
        const size = nodeList.length;
        const matrix = Array.from({ length: size }, () => new Array(size).fill(0));
        for (const [u, edges] of this.adjList) {
            for (const { node: v, weight } of edges) {
                matrix[index.get(u)][index.get(v)] = weight;
            }
        }
        return { nodeList, matrix };
    }

    bfs(start) {
        const visited = new Set([start]);
        const order = [];
        const queue = [start];
        while (queue.length) {
            const current = queue.shift();
            order.push(current);
            for (const { node: neighbor } of this.adjList.get(current) || []) {
                if (!visited.has(neighbor)) {
                    visited.add(neighbor);
                    queue.push(neighbor);
                }
            }
        }
        return order;
    }

    dfs(start) {
        const visited = new Set();
        const order = [];
        const walk = (node) => {
            visited.add(node);
            order.push(node);
            for (const { node: neighbor } of this.adjList.get(node) || []) {
                if (!visited.has(neighbor)) walk(neighbor);
            }
        };
        walk(start);
        return order;
    }

    connectedComponents() {
        const undirectedView = new Map();
        for (const node of this.nodes()) undirectedView.set(node, new Set());
        for (const [u, edges] of this.adjList) {
            for (const { node: v } of edges) {
                undirectedView.get(u).add(v);
                undirectedView.get(v).add(u);
            }
        }

        const visited = new Set();
        const components = [];
        for (const start of this.nodes()) {
            if (visited.has(start)) continue;
            const component = [];
            const queue = [start];
            visited.add(start);
            while (queue.length) {
                const current = queue.shift();
                component.push(current);
                for (const neighbor of undirectedView.get(current)) {
                    if (!visited.has(neighbor)) {
                        visited.add(neighbor);
                        queue.push(neighbor);
                    }
                }
            }
            components.push(component);
        }
        return components;
    }

    shortestPathUnweighted(start, end) {
        const visited = new Set([start]);
        const queue = [[start]];
        while (queue.length) {
            const path = queue.shift();
            const node = path[path.length - 1];
            if (node === end) return { path, hops: path.length - 1 };
            for (const { node: neighbor } of this.adjList.get(node) || []) {
                if (!visited.has(neighbor)) {
                    visited.add(neighbor);
                    queue.push([...path, neighbor]);
                }
            }
        }
        return null;
    }

    shortestPathDijkstra(start, end) {
        const dist = new Map(this.nodes().map(n => [n, Infinity]));
        const prev = new Map();
        dist.set(start, 0);
        const unvisited = new Set(this.nodes());

        while (unvisited.size) {
            let current = null;
            let best = Infinity;
            for (const node of unvisited) {
                if (dist.get(node) < best) {
                    best = dist.get(node);
                    current = node;
                }
            }
            if (current === null) break;
            unvisited.delete(current);
            if (current === end) break;

            for (const { node: neighbor, weight } of this.adjList.get(current) || []) {
                const alt = dist.get(current) + weight;
                if (alt < dist.get(neighbor)) {
                    dist.set(neighbor, alt);
                    prev.set(neighbor, current);
                }
            }
        }

        if (dist.get(end) === Infinity) return null;
        const path = [];
        let node = end;
        while (node !== undefined) {
            path.unshift(node);
            node = prev.get(node);
        }
        return { path, distance: dist.get(end) };
    }
}

function buildCampusGraph() {
    const g = new Graph(false);
    g.addEdge("MainGate", "EngineeringBlock", 300);
    g.addEdge("EngineeringBlock", "ScienceBlock", 200);
    g.addEdge("EngineeringBlock", "Library", 250);
    g.addEdge("ScienceBlock", "Library", 180);
    g.addEdge("Library", "Cafeteria", 120);
    g.addEdge("EngineeringBlock", "Cafeteria", 350);
    g.addEdge("Cafeteria", "Hostels", 400);
    g.addEdge("ParkingArea", "MainGate", 150, true);
    g.addEdge("Hostels", "MainGate", 500, true);
    return g;
}

if (require.main === module) {
    const campusGraph = buildCampusGraph();

    console.log("Nodes:", campusGraph.nodes());

    const { nodeList, matrix } = campusGraph.toAdjacencyMatrix();
    console.log("\nAdjacency matrix order:", nodeList);
    matrix.forEach(row => console.log(row));

    console.log("\nBFS from MainGate:", campusGraph.bfs("MainGate"));
    console.log("DFS from MainGate:", campusGraph.dfs("MainGate"));

    console.log("\nConnected components (weakly connected, direction ignored):", campusGraph.connectedComponents());

    console.log("\nShortest path MainGate -> Hostels (unweighted, hops):",
        campusGraph.shortestPathUnweighted("MainGate", "Hostels"));

    console.log("Shortest path MainGate -> Hostels (Dijkstra, weighted):",
        campusGraph.shortestPathDijkstra("MainGate", "Hostels"));
}

module.exports = { Graph, buildCampusGraph };
