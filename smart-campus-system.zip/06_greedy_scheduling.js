function selectMaxNonOverlappingEvents(events) {
    const sorted = [...events].sort((a, b) => a.end - b.end);
    const selected = [];
    let lastEndTime = -Infinity;

    for (const event of sorted) {
        if (event.start >= lastEndTime) {
            selected.push(event);
            lastEndTime = event.end;
        }
    }
    return selected;
}

if (require.main === module) {
    const events = [
        { name: "Data Structures Lecture", room: "Room 101", start: 9, end: 10 },
        { name: "Mid-Sem Exam", room: "Room 101", start: 9.5, end: 11.5 },
        { name: "AI Workshop", room: "Room 101", start: 10, end: 12 },
        { name: "Placement Meeting", room: "Room 101", start: 12, end: 13 },
        { name: "Alumni Talk", room: "Room 101", start: 11, end: 13.5 },
        { name: "Coding Club", room: "Room 101", start: 13, end: 14 }
    ];

    const selected = selectMaxNonOverlappingEvents(events);
    console.log(`Selected ${selected.length} of ${events.length} events for Room 101 (max non-overlapping):`);
    selected.forEach(e => console.log(` ${e.name}: ${e.start} - ${e.end}`));
}

module.exports = { selectMaxNonOverlappingEvents };
