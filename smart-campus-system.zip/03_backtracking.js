const { buildCampusGraph } = require("./02_graph.js");

function findAllRoutesWithinBudget(graph, start, end, budget) {
    const results = [];
    const visited = new Set();
    const path = [start];

    function explore(current, distanceSoFar) {
        if (distanceSoFar > budget) {
            return;
        }

        if (current === end) {
            results.push({ path: [...path], distance: distanceSoFar });
            return;
        }

        visited.add(current);
        for (const { node: neighbor, weight } of graph.adjList.get(current) || []) {
            if (visited.has(neighbor)) continue;
            if (distanceSoFar + weight > budget) continue;

            path.push(neighbor);
            explore(neighbor, distanceSoFar + weight);
            path.pop();
        }
        visited.delete(current);
    }

    explore(start, 0);
    return results;
}

if (require.main === module) {
    const graph = buildCampusGraph();

    console.log("All routes MainGate -> Hostels within 1200m budget:");
    const routes = findAllRoutesWithinBudget(graph, "MainGate", "Hostels", 1200);
    routes.forEach(r => console.log(` ${r.path.join(" -> ")}  (${r.distance}m)`));

    console.log("\nAll routes MainGate -> Hostels within a tight 900m budget (pruned harder):");
    const tightRoutes = findAllRoutesWithinBudget(graph, "MainGate", "Hostels", 900);
    if (tightRoutes.length === 0) console.log(" none within budget");
    tightRoutes.forEach(r => console.log(` ${r.path.join(" -> ")}  (${r.distance}m)`));
}

module.exports = { findAllRoutesWithinBudget };
