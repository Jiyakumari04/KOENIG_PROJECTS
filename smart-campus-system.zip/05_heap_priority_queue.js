class MaxHeap {
    constructor() {
        this.items = [];
    }

    parentIndex(i) { return Math.floor((i - 1) / 2); }
    leftIndex(i) { return 2 * i + 1; }
    rightIndex(i) { return 2 * i + 2; }

    swap(i, j) {
        [this.items[i], this.items[j]] = [this.items[j], this.items[i]];
    }

    insert(request) {
        this.items.push(request);
        this.siftUp(this.items.length - 1);
    }

    siftUp(i) {
        while (i > 0 && this.items[this.parentIndex(i)].priority < this.items[i].priority) {
            this.swap(i, this.parentIndex(i));
            i = this.parentIndex(i);
        }
    }

    extractMax() {
        if (this.items.length === 0) return null;
        const max = this.items[0];
        const last = this.items.pop();
        if (this.items.length > 0) {
            this.items[0] = last;
            this.siftDown(0);
        }
        return max;
    }

    siftDown(i) {
        let largest = i;
        const left = this.leftIndex(i);
        const right = this.rightIndex(i);

        if (left < this.items.length && this.items[left].priority > this.items[largest].priority) {
            largest = left;
        }
        if (right < this.items.length && this.items[right].priority > this.items[largest].priority) {
            largest = right;
        }
        if (largest !== i) {
            this.swap(i, largest);
            this.siftDown(largest);
        }
    }

    peek() {
        return this.items.length ? this.items[0] : null;
    }

    isEmpty() {
        return this.items.length === 0;
    }

    size() {
        return this.items.length;
    }
}

if (require.main === module) {
    const heap = new MaxHeap();
    const requests = [
        { id: "M1", description: "Flickering lights - Library", priority: 2 },
        { id: "M2", description: "Water leak - Science Block", priority: 5 },
        { id: "M3", description: "AC not working - Cafeteria", priority: 3 },
        { id: "M4", description: "Gas smell - Chemistry Lab", priority: 9 },
        { id: "M5", description: "Broken chair - Reading Hall", priority: 1 }
    ];

    requests.forEach(r => heap.insert(r));

    console.log("Heap array (internal, not sorted, satisfies max-heap property):");
    console.log(heap.items.map(r => `${r.id}(${r.priority})`));

    console.log("\nProcessing requests by priority (highest first):");
    while (!heap.isEmpty()) {
        const next = heap.extractMax();
        console.log(` handling ${next.id} [priority ${next.priority}]: ${next.description}`);
    }
}

module.exports = { MaxHeap };
