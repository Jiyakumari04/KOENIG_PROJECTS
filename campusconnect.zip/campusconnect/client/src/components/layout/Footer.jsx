function Footer() {
  const year = new Date().getFullYear();
  return (
    <footer className="site-footer">
      <p style={{ margin: 0, maxWidth: 'none' }}>
        &copy; {year} CampusConnect, a project of the Office of Student Life.
      </p>
    </footer>
  );
}

export default Footer;
