/**
 * Reusable Button.
 * variant: 'primary' | 'secondary'
 * Renders a <button> unless an `as="a"`-style link is needed elsewhere (Link is used directly for routes).
 */
function Button({
  children,
  variant = 'primary',
  type = 'button',
  fullWidth = false,
  disabled = false,
  onClick,
}) {
  const classes = [
    'btn',
    variant === 'secondary' ? 'btn-secondary' : 'btn-primary',
    fullWidth ? 'btn-block' : '',
  ]
    .filter(Boolean)
    .join(' ');

  return (
    <button type={type} className={classes} disabled={disabled} onClick={onClick}>
      {children}
    </button>
  );
}

export default Button;
