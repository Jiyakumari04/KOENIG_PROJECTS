/**
 * Controlled input field with a label and inline validation message.
 * Used by both the Login and Registration forms so validation styling
 * stays consistent across the app.
 */
function FormInput({ id, label, type = 'text', value, onChange, error, autoComplete }) {
  return (
    <div className="field">
      <label htmlFor={id}>{label}</label>
      <input
        id={id}
        name={id}
        type={type}
        value={value}
        onChange={onChange}
        autoComplete={autoComplete}
        className={error ? 'has-error' : ''}
        aria-invalid={Boolean(error)}
        aria-describedby={error ? `${id}-error` : undefined}
      />
      {error && (
        <div className="field-error" id={`${id}-error`}>
          {error}
        </div>
      )}
    </div>
  );
}

export default FormInput;
