/**
 * Inline banner for success/error feedback. Renders nothing when there's
 * no message, so callers can do `<Alert type="error" message={formError} />`
 * unconditionally and rely on conditional rendering here.
 */
function Alert({ type = 'error', message }) {
  if (!message) return null;

  const className = type === 'success' ? 'alert alert-success' : 'alert alert-error';

  return (
    <div className={className} role={type === 'error' ? 'alert' : 'status'}>
      {message}
    </div>
  );
}

export default Alert;
