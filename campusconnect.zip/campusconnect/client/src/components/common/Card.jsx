/**
 * Generic Card container. `variant="feature"` adds the brass accent border
 * used on the home page's feature row.
 */
function Card({ children, variant, className = '' }) {
  const classes = ['card', variant === 'feature' ? 'card-feature' : '', className]
    .filter(Boolean)
    .join(' ');

  return <div className={classes}>{children}</div>;
}

export default Card;
