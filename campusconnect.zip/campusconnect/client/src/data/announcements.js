/**
 * Stand-in for GET /api/announcements. Each entry has a unique `id`
 * that the Dashboard uses as the React list key.
 */
const announcements = [
  {
    id: 'ann-1',
    tag: 'Registrar',
    date: 'Sep 15',
    title: 'Spring semester course registration opens Monday',
    body: 'Priority registration windows are assigned by credit hours. Check your student portal for your exact time slot.',
  },
  {
    id: 'ann-2',
    tag: 'Student Life',
    date: 'Sep 12',
    title: 'Campus club fair moves to the quad',
    body: 'Over 60 student organizations will be tabling from 11am to 3pm. Free lunch while supplies last.',
  },
  {
    id: 'ann-3',
    tag: 'IT Services',
    date: 'Sep 10',
    title: 'Scheduled Wi-Fi maintenance in the library',
    body: 'Network access in the east wing will be intermittent between 1am and 4am Thursday for infrastructure upgrades.',
  },
  {
    id: 'ann-4',
    tag: 'Financial Aid',
    date: 'Sep 8',
    title: 'FAFSA renewal reminder for continuing students',
    body: 'Renew before October 1 to avoid a gap in disbursement for the coming term.',
  },
  {
    id: 'ann-5',
    tag: 'Athletics',
    date: 'Sep 5',
    title: 'Homecoming game tickets now available',
    body: 'Students get one free ticket with a valid ID at the box office, limit one per student.',
  },
];

export default announcements;
