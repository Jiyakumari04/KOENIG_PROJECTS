import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import FormInput from '../components/common/FormInput.jsx';
import Button from '../components/common/Button.jsx';
import Alert from '../components/common/Alert.jsx';
import { validateLogin } from '../utils/validation.js';

const INITIAL_FORM = { email: '', password: '' };

function Login() {
  const navigate = useNavigate();
  const [form, setForm] = useState(INITIAL_FORM);
  const [errors, setErrors] = useState({});
  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState('');

  function handleChange(event) {
    const { name, value } = event.target;
    setForm((prev) => ({ ...prev, [name]: value }));
    setErrors((prev) => (prev[name] ? { ...prev, [name]: undefined } : prev));
  }

  function handleSubmit(event) {
    event.preventDefault();
    setSubmitError('');

    const validationErrors = validateLogin(form);
    setErrors(validationErrors);
    if (Object.keys(validationErrors).length > 0) {
      return;
    }

    setSubmitting(true);

    // TODO: replace with POST /api/auth/login once the server is wired up.
    window.setTimeout(() => {
      setSubmitting(false);
      navigate('/dashboard');
    }, 600);
  }

  return (
    <div className="auth-wrap">
      <h1>Log in</h1>
      <p>Welcome back. Enter your student email and password to continue.</p>

      <div className="auth-card">
        <Alert type="error" message={submitError} />

        <form onSubmit={handleSubmit} noValidate>
          <FormInput
            id="email"
            label="Email address"
            type="email"
            value={form.email}
            onChange={handleChange}
            error={errors.email}
            autoComplete="email"
          />
          <FormInput
            id="password"
            label="Password"
            type="password"
            value={form.password}
            onChange={handleChange}
            error={errors.password}
            autoComplete="current-password"
          />

          {submitting ? (
            <div className="loading-line">
              <span className="spinner" aria-hidden="true" />
              Signing you in…
            </div>
          ) : (
            <Button type="submit" fullWidth>
              Log in
            </Button>
          )}
        </form>

        <p className="form-footnote">
          New here? <Link to="/register">Create an account</Link>
        </p>
      </div>
    </div>
  );
}

export default Login;
