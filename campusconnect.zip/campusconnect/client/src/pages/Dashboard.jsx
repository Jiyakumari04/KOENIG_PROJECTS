import { useEffect, useState } from 'react';
import announcementsData from '../data/announcements.js';

const STATS = [
  { label: 'Announcements', value: announcementsData.length },
  { label: 'Enrolled courses', value: 5 },
  { label: 'Days until finals', value: 42 },
];

function Dashboard() {
  const [announcements, setAnnouncements] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Simulates GET /api/announcements. Swap this effect for a fetch()
    // call once the endpoint exists; the render logic below won't change.
    const timer = window.setTimeout(() => {
      setAnnouncements(announcementsData);
      setLoading(false);
    }, 500);

    return () => window.clearTimeout(timer);
  }, []);

  return (
    <div>
      <div className="dash-header">
        <div className="dash-greeting">
          <h1 style={{ marginBottom: '0.2rem' }}>Welcome back</h1>
          <p>Here's what's happening across campus this week.</p>
        </div>
      </div>

      <div className="stat-row">
        {STATS.map((stat) => (
          <div className="stat" key={stat.label}>
            <span className="stat-num">{stat.value}</span>
            <span className="stat-label">{stat.label}</span>
          </div>
        ))}
      </div>

      <div className="section-title-row">
        <h2>Announcements</h2>
      </div>

      {loading ? (
        <div className="loading-line">
          <span className="spinner" aria-hidden="true" />
          Loading announcements…
        </div>
      ) : announcements.length === 0 ? (
        <p>There are no announcements right now. Check back soon.</p>
      ) : (
        <div className="notice-board">
          {announcements.map((item) => (
            <article className="notice" key={item.id}>
              <div className="notice-meta">
                <span className="notice-tag">{item.tag}</span>
                <span>{item.date}</span>
              </div>
              <h3>{item.title}</h3>
              <p>{item.body}</p>
            </article>
          ))}
        </div>
      )}
    </div>
  );
}

export default Dashboard;
