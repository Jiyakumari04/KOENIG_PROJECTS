import { Link } from 'react-router-dom';
import Card from '../components/common/Card.jsx';
import Button from '../components/common/Button.jsx';

const FEATURES = [
  {
    title: 'One login, every service',
    body: 'Registration, housing, dining, and clubs all sit behind a single student account.',
  },
  {
    title: 'A dashboard that stays current',
    body: 'Announcements, deadlines, and updates from every campus office land in one feed.',
  },
  {
    title: 'Built for a phone in your hand',
    body: 'Check a deadline between classes without waiting on a page to reload.',
  },
];

function Home() {
  return (
    <div>
      <section className="hero">
        <div>
          <div className="hero-eyebrow">Student Activity Management Portal</div>
          <h1>Everything happening on campus, in one place.</h1>
          <p>
            CampusConnect brings registration, announcements, and your personal dashboard
            together, so you spend less time hunting through email and more time on
            campus.
          </p>
          <div className="hero-actions">
            <Link to="/register">
              <Button variant="primary">Create your account</Button>
            </Link>
            <Link to="/login">
              <Button variant="secondary">I already have one</Button>
            </Link>
          </div>
        </div>

        <div className="hero-art" aria-hidden="true">
          <svg width="240" height="220" viewBox="0 0 240 220" fill="none">
            <rect x="10" y="90" width="220" height="110" fill="#fffdf8" stroke="#ddd6c3" />
            <rect x="30" y="60" width="180" height="40" fill="#23304d" />
            <polygon points="20,60 120,10 220,60" fill="#17203a" />
            <rect x="105" y="130" width="30" height="70" fill="#b8863f" />
            <rect x="45" y="115" width="18" height="24" fill="#23304d" />
            <rect x="85" y="115" width="18" height="24" fill="#23304d" />
            <rect x="140" y="115" width="18" height="24" fill="#23304d" />
            <rect x="178" y="115" width="18" height="24" fill="#23304d" />
          </svg>
        </div>
      </section>

      <section aria-labelledby="features-heading">
        <h2 id="features-heading" style={{ marginBottom: '0.25rem' }}>
          Why students use CampusConnect
        </h2>
        <p>A single portal built specifically around the campus routine.</p>
        <div className="feature-row">
          {FEATURES.map((feature) => (
            <Card key={feature.title} variant="feature">
              <h3>{feature.title}</h3>
              <p>{feature.body}</p>
            </Card>
          ))}
        </div>
      </section>
    </div>
  );
}

export default Home;
