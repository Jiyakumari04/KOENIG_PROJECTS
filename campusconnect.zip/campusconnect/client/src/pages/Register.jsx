import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import FormInput from '../components/common/FormInput.jsx';
import Button from '../components/common/Button.jsx';
import Alert from '../components/common/Alert.jsx';
import { validateRegistration } from '../utils/validation.js';

const INITIAL_FORM = {
  name: '',
  email: '',
  password: '',
  confirmPassword: '',
};

function Register() {
  const navigate = useNavigate();
  const [form, setForm] = useState(INITIAL_FORM);
  const [errors, setErrors] = useState({});
  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState('');
  const [success, setSuccess] = useState(false);

  function handleChange(event) {
    const { name, value } = event.target;
    setForm((prev) => ({ ...prev, [name]: value }));
    // Clear a field's error as soon as the user edits it again.
    setErrors((prev) => (prev[name] ? { ...prev, [name]: undefined } : prev));
  }

  function handleSubmit(event) {
    event.preventDefault();
    setSubmitError('');

    const validationErrors = validateRegistration(form);
    setErrors(validationErrors);
    if (Object.keys(validationErrors).length > 0) {
      return;
    }

    setSubmitting(true);

    // TODO: replace with POST /api/auth/register once the server is wired up.
    window.setTimeout(() => {
      setSubmitting(false);
      setSuccess(true);
      setForm(INITIAL_FORM);
      window.setTimeout(() => navigate('/login'), 1200);
    }, 700);
  }

  return (
    <div className="auth-wrap">
      <h1>Create your account</h1>
      <p>Registration takes about a minute. You'll use this account to log in each visit.</p>

      <div className="auth-card">
        <Alert type="error" message={submitError} />
        <Alert
          type="success"
          message={success ? 'Account created. Redirecting you to log in…' : ''}
        />

        <form onSubmit={handleSubmit} noValidate>
          <FormInput
            id="name"
            label="Full name"
            value={form.name}
            onChange={handleChange}
            error={errors.name}
            autoComplete="name"
          />
          <FormInput
            id="email"
            label="Email address"
            type="email"
            value={form.email}
            onChange={handleChange}
            error={errors.email}
            autoComplete="email"
          />
          <FormInput
            id="password"
            label="Password"
            type="password"
            value={form.password}
            onChange={handleChange}
            error={errors.password}
            autoComplete="new-password"
          />
          <FormInput
            id="confirmPassword"
            label="Confirm password"
            type="password"
            value={form.confirmPassword}
            onChange={handleChange}
            error={errors.confirmPassword}
            autoComplete="new-password"
          />

          {submitting ? (
            <div className="loading-line">
              <span className="spinner" aria-hidden="true" />
              Creating your account…
            </div>
          ) : (
            <Button type="submit" fullWidth>
              Create account
            </Button>
          )}
        </form>

        <p className="form-footnote">
          Already registered? <Link to="/login">Log in</Link>
        </p>
      </div>
    </div>
  );
}

export default Register;
