Shared static assets (logos, illustrations, icons) go here. The home page
currently uses an inline SVG placeholder in `client/src/pages/Home.jsx`;
replace it with a real campus illustration or photo dropped into this folder
and imported from `client/src`.
