# Architecture notes

## Why Vite instead of Create React App

Create React App is no longer maintained; Vite gives the same "run `npm run dev`
and go" experience with a much faster dev server and build, and drops straight
into a standard `src/` layout that matches what this lab expects.

## Component map

```
Layout
├── Header
│   └── NavBar (NavLink items, mobile toggle)
└── Footer

Home        -> Card (feature variant) x3, Button x2
Login       -> FormInput x2, Button, Alert
Register    -> FormInput x4, Button, Alert
Dashboard   -> stat cards, notice-board list (Card-less, custom `.notice` style)
```

`Layout` is the single place that renders `Header` and `Footer`; every route in
`App.jsx` is rendered as `Layout`'s children, so adding a new page never means
re-adding navigation or the footer.

## State ownership

- Form state (`form`, `errors`, `submitting`) lives locally in `Login.jsx` and
  `Register.jsx` via `useState` — no global state library is needed yet.
- `Dashboard.jsx` owns its own `announcements` and `loading` state, currently
  populated from the local mock in `data/announcements.js` inside a
  `useEffect` that mimics a network delay.
- Once real authentication exists, promote a small amount of state (e.g. the
  logged-in user) to a top-level context so `Dashboard` can read it without
  prop-drilling through `App.jsx`.

## Validation strategy

`utils/validation.js` exports pure functions (`validateRegistration`,
`validateLogin`) that take the current form values and return an `errors`
object. Keeping validation logic outside the components makes it unit-testable
on its own and keeps the JSX focused on rendering.
