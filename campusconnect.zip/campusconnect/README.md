# CampusConnect

A student activity management portal built on the MERN stack (MongoDB, Express, React, Node.js). This is the Phase 1 deliverable: a complete React front-end, structured so an Express/MongoDB back-end can be wired in without reshaping the client.

## Project structure

```
campusconnect/
├── client/                 React front-end (Vite)
│   ├── public/
│   └── src/
│       ├── components/
│       │   ├── layout/     Header, NavBar, Footer, Layout shell
│       │   └── common/     Button, Card, FormInput, Alert – reusable UI primitives
│       ├── pages/          Home, Login, Register, Dashboard, NotFound
│       ├── data/           Mock announcement data (stand-in for the future API)
│       ├── utils/          Form validation helpers
│       ├── App.jsx         Route table
│       ├── main.jsx        React entry point
│       └── index.css       Design tokens + global styles
├── server/                 Node/Express API (stub, ready for MongoDB models + routes)
│   └── src/server.js
├── docs/                   Shared documentation
└── assets/                 Shared static assets (logos, icons, images)
```

## Getting started

### Client

```bash
cd client
npm install
npm run dev
```

The dev server runs at `http://localhost:5173`.

### Server (stub)

```bash
cd server
npm install
npm run dev
```

The API stub listens on `http://localhost:5000` and exposes a single `/api/health` route. Registration, login, and announcement endpoints are left as clearly marked TODOs for the next phase, once MongoDB models are introduced.

## What's implemented

- **Routing** – client-side navigation between Home, Login, Register, and Dashboard with React Router, no full page reloads.
- **Layout** – a shared Header, NavBar, and Footer wrap every page via a single `Layout` component.
- **Forms** – controlled Registration and Login forms with field-level validation (required fields, email format, password rules, confirm-password match) and inline error/success feedback.
- **State & events** – `useState` for form and UI state, event handlers for input changes, submissions, and navigation.
- **Conditional rendering** – validation errors, a submitting/loading state, and a success message all render conditionally based on state.
- **Dynamic lists** – the Dashboard renders a mock announcements collection from `data/announcements.js`, each with a unique `id` used as the React `key`.
- **Responsive layout** – a mobile nav toggle and a fluid grid keep the app usable from phone width up to desktop.

## Next phase (not yet built)

- Replace `data/announcements.js` with a `GET /api/announcements` call.
- Replace the mock submit handlers in Login/Register with `POST /api/auth/login` and `POST /api/auth/register`.
- Add MongoDB models (`User`, `Announcement`) and Express routes in `server/src`.
- Add auth state (e.g. a token in context) so `Dashboard` can be protected once real auth exists.
