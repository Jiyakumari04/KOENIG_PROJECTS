import 'dotenv/config';
import express from 'express';
import cors from 'cors';

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(express.json());

app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', service: 'campusconnect-server' });
});

// TODO (next phase): connect to MongoDB (e.g. via mongoose) and add:
//   POST   /api/auth/register   -> create a User document
//   POST   /api/auth/login      -> verify credentials, issue a session/JWT
//   GET    /api/announcements   -> return the Announcement collection
//   POST   /api/announcements   -> (admin) create a new announcement
//
// Once these exist, the client's Register.jsx, Login.jsx, and Dashboard.jsx
// TODO comments show exactly where to swap in the real fetch() calls.

app.listen(PORT, () => {
  console.log(`CampusConnect API stub listening on http://localhost:${PORT}`);
});
