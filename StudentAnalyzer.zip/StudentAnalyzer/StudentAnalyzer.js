let students = [
  { id: 101, name: "Aarav", marks: [78, 85, 90], feedback: "Excellent" },
  { id: 102, name: "Diya", marks: [65, 72, 68], feedback: "Good" },
  { id: 103, name: "Rohan", marks: [90, 88, 95], feedback: "Excellent" },
];

// 1. Calculate total marks

function calculateTotal(marks) {
  let total = 0;

  for (let mark of marks) {
    total += mark;
  }

  return total;
}

// 2. Calculate average marks

function calculateAverage(marks) {
  if (marks.length === 0) {
    return 0;
  }

  return calculateTotal(marks) / marks.length;
}

// 3. Find highest mark

function findHighestMark(students) {
  if (students.length === 0) {
    return null;
  }

  let highest = students[0].marks[0];

  for (let student of students) {
    for (let mark of student.marks) {
      if (mark > highest) {
        highest = mark;
      }
    }
  }

  return highest;
}

// 4. Find highest performer

function findHighestPerformer(students) {
  if (students.length === 0) {
    return null;
  }

  let highest = students[0];

  for (let student of students) {
    if (calculateAverage(student.marks) > calculateAverage(highest.marks)) {
      highest = student;
    }
  }

  return highest;
}

// 5. Search student by ID

function searchStudent(students, id) {
  for (let student of students) {
    if (student.id === id) {
      return student;
    }
  }

  return null;
}

// 6. Insert new student

function insertStudent(students, student) {
  students.push(student);
}

// 7. Delete student by ID

function deleteStudent(students, id) {
  let index = students.findIndex((student) => student.id === id);

  if (index !== -1) {
    students.splice(index, 1);
    return true;
  }

  return false;
}

// 8. Traverse multidimensional marks array

function traverseMarks(students) {
  for (let i = 0; i < students.length; i++) {
    for (let j = 0; j < students[i].marks.length; j++) {
      console.log(students[i].marks[j]);
    }
  }
}

// 9. Character frequency

function characterFrequency(text) {
  let frequency = {};

  text = text.toLowerCase();

  for (let char of text) {
    if (char === " ") {
      continue;
    }

    if (frequency[char]) {
      frequency[char]++;
    } else {
      frequency[char] = 1;
    }
  }

  return frequency;
}

// 10. Most frequent character

function mostFrequentCharacter(text) {
  let frequency = characterFrequency(text);

  let maxChar = "";
  let maxCount = 0;

  for (let char in frequency) {
    if (frequency[char] > maxCount) {
      maxCount = frequency[char];
      maxChar = char;
    }
  }

  return maxChar;
}

// 11. Check divisibility

function checkDivisibility(num) {
  console.log("Divisible by 2:", num % 2 === 0);
  console.log("Divisible by 3:", num % 3 === 0);
  console.log("Divisible by 5:", num % 5 === 0);
  console.log("Divisible by 7:", num % 7 === 0);
}

// 12. Prime number

function isPrime(num) {
  if (num < 2) {
    return false;
  }

  for (let i = 2; i * i <= num; i++) {
    if (num % i === 0) {
      return false;
    }
  }

  return true;
}

// 13. GCD

function gcd(a, b) {
  a = Math.abs(a);
  b = Math.abs(b);

  while (b !== 0) {
    let remainder = a % b;
    a = b;
    b = remainder;
  }

  return a;
}

// 14. LCM

function lcm(a, b) {
  if (a === 0 || b === 0) {
    return 0;
  }

  return Math.abs(a * b) / gcd(a, b);
}

// 15. Performance pattern

function performancePattern(average) {
  let rows = Math.floor(average / 20);

  for (let i = 1; i <= rows; i++) {
    console.log("*".repeat(i));
  }
}

// 16. Reverse marks in-place

function reverseMarks(marks) {
  let left = 0;
  let right = marks.length - 1;

  while (left < right) {
    let temp = marks[left];

    marks[left] = marks[right];
    marks[right] = temp;

    left++;
    right--;
  }
}

// ========================================
// STUDENT PERFORMANCE REPORT
// ========================================

console.log("Student Performance Report");
console.log("--------------------------");

for (let student of students) {
  let total = calculateTotal(student.marks);
  let average = calculateAverage(student.marks);

  console.log(
    `${student.name}  Total: ${total}  Average: ${average.toFixed(2)}`,
  );
}

// Highest mark

console.log("\nHighest Mark:", findHighestMark(students));

// Highest performer

let highestPerformer = findHighestPerformer(students);

console.log("Highest Performer:", highestPerformer.name);

// Search student

let searchId = 102;

let result = searchStudent(students, searchId);

console.log("\nSearch Student ID:", searchId);

if (result !== null) {
  console.log("Student Found:", result.name);
} else {
  console.log("Student Not Found");
}

// Insert student

let newStudent = {
  id: 104,
  name: "Kabir",
  marks: [82, 76, 89],
  feedback: "Very Good",
};

insertStudent(students, newStudent);

console.log("\nAfter Inserting New Student:");

for (let student of students) {
  console.log(student.name);
}

// Delete student

deleteStudent(students, 104);

console.log("\nAfter Deleting Student ID 104:");

for (let student of students) {
  console.log(student.name);
}

// Traverse marks

console.log("\nAll Marks:");

traverseMarks(students);

// Character frequency for all feedback

console.log("\nCharacter Frequency:");

let allFeedback = "";

for (let student of students) {
  allFeedback += student.feedback + " ";
}

let frequency = characterFrequency(allFeedback);

for (let char in frequency) {
  console.log(`${char} : ${frequency[char]}`);
}

// Most frequent character

console.log("Most Frequent Character:", mostFrequentCharacter(allFeedback));

// Number processing

let number = 101;

console.log("\nNumber Processing");
console.log("Number:", number);

checkDivisibility(number);

console.log("Prime:", isPrime(number));

// GCD and LCM

let a = 12;
let b = 18;

console.log("\nGCD:", gcd(a, b));
console.log("LCM:", lcm(a, b));

// Performance pattern

console.log("\nPerformance Pattern:");

let average = calculateAverage(students[0].marks);

performancePattern(average);

// In-place reverse

console.log("\nOriginal Marks:", students[0].marks);

reverseMarks(students[0].marks);

console.log("Reversed Marks:", students[0].marks);
