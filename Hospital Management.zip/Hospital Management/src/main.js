// main.js
// runs through everything for the lab demo, using the same sample data
// throughout so it's easy to follow
//
// run with: node src/main.js

const { getSamplePatients } = require("./sampleData");
const { linearSearchById, binarySearchById } = require("./searching");
const { bubbleSort, selectionSort, insertionSort, mergeSort, quickSort } = require("./sorting");
const { SinglyLinkedList, DoublyLinkedList } = require("./LinkedList");
const { ArrayStack, LinkedListStack } = require("./Stack");
const { Queue, CircularQueue, Deque } = require("./Queue");
const { HashTable, HashSet, frequencyCount, mostFrequent } = require("./HashTable");
const { twoPointerFindPairWithSum, maxArrivalsInWindow } = require("./patterns");

function section(title) {
  console.log("\n" + "=".repeat(70));
  console.log(title);
  console.log("=".repeat(70));
}

function printList(patients) {
  patients.forEach((p) => console.log("  " + p.toString()));
}

const patients = getSamplePatients();

// ---------------------------------------------------------
section("0. sample dataset (order patients arrived at the desk)");
// ---------------------------------------------------------
printList(patients);

// ---------------------------------------------------------
section("1. searching - linear vs binary search");
// ---------------------------------------------------------
const targetId = 108;

const linResult = linearSearchById(patients, targetId);
console.log(`linear search for id ${targetId} -> found in ${linResult.comparisons} comparisons`);
console.log("  " + (linResult.patient ? linResult.patient.toString() : "not found"));

// gotta sort by id first for binary search to actually work
const sortedById = [...patients].sort((a, b) => a.id - b.id);
const binResult = binarySearchById(sortedById, targetId);
console.log(`binary search for id ${targetId} (sorted array) -> found in ${binResult.comparisons} comparisons`);
console.log("  " + (binResult.patient ? binResult.patient.toString() : "not found"));
console.log("\n(binary search took way fewer comparisons, but only works because we sorted first)");

// ---------------------------------------------------------
section("2. sorting - bubble / selection / insertion / merge / quick");
// ---------------------------------------------------------
console.log("by priority (bubble sort):");
printList(bubbleSort(patients, "priority"));

console.log("\nby id (selection sort):");
printList(selectionSort(patients, "id"));

console.log("\nby arrival time (insertion sort):");
printList(insertionSort(patients, "arrivalTime"));

console.log("\nby priority (merge sort - stable, O(n log n)):");
printList(mergeSort(patients, "priority"));

console.log("\nby arrival time (quick sort - avg O(n log n)):");
printList(quickSort(patients, "arrivalTime"));

console.log("\nwith only 10 records all of these run instantly, but once the hospital's");
console.log("archive has thousands of records the O(n^2) sorts get way too slow, hence");
console.log("merge/quick sort for anything big.");

// ---------------------------------------------------------
section("3. linked lists - singly and doubly");
// ---------------------------------------------------------
const sll = new SinglyLinkedList();
patients.forEach((p) => sll.insertAtEnd(p));

console.log("singly linked list (arrival order):");
printList(sll.traverse());

sll.deleteById(103); // pretend this patient got discharged
console.log("\nafter discharging patient 103:");
printList(sll.traverse());

const dll = new DoublyLinkedList();
patients.forEach((p) => dll.insertAtEnd(p));

console.log("\ndoubly linked list - forward:");
printList(dll.traverseForward());
console.log("\ndoubly linked list - backward (staff reviewing most recent first):");
printList(dll.traverseBackward());

// ---------------------------------------------------------
section("4. stacks - undo feature (array vs linked list)");
// ---------------------------------------------------------
const undoStackArr = new ArrayStack();
undoStackArr.push({ type: "TRANSFER", patientId: 104, from: "Orthopedics", to: "Physiotherapy" });
undoStackArr.push({ type: "DELETE", patient: patients.find((p) => p.id === 109) });

console.log("array stack - peek:", undoStackArr.peek());
console.log("array stack - pop (undo):", undoStackArr.pop());
console.log("array stack - isEmpty now?", undoStackArr.isEmpty());

const undoStackLL = new LinkedListStack();
undoStackLL.push({ type: "TRANSFER", patientId: 104, from: "Orthopedics", to: "Physiotherapy" });
undoStackLL.push({ type: "DELETE", patient: patients.find((p) => p.id === 109) });

console.log("\nlinked list stack - peek:", undoStackLL.peek());
console.log("linked list stack - pop (undo):", undoStackLL.pop());
console.log("linked list stack - isEmpty now?", undoStackLL.isEmpty());

// ---------------------------------------------------------
section("5. queues - normal queue, circular queue, deque");
// ---------------------------------------------------------
const routineQueue = new Queue();
patients.filter((p) => p.priority === 3).forEach((p) => routineQueue.enqueue(p));

console.log("routine queue (fcfs):");
console.log("  next up:", routineQueue.peek().toString());
console.log("  dequeue:", routineQueue.dequeue().toString());
console.log("  left in queue:", routineQueue.size());

const waitingRoom = new CircularQueue(3); // only 3 chairs available
console.log("\ncircular queue - 3 chair waiting room:");
console.log("  enqueue #1:", waitingRoom.enqueue(patients[3]));
console.log("  enqueue #2:", waitingRoom.enqueue(patients[7]));
console.log("  enqueue #3:", waitingRoom.enqueue(patients[6]));
console.log("  enqueue #4 (should fail, room's full):", waitingRoom.enqueue(patients[8]));

const freedChair = waitingRoom.dequeue();
console.log("  dequeue (chair opens up):", freedChair.toString());
console.log("  enqueue again (reuses that chair):", waitingRoom.enqueue(patients[8]));

const staffDeque = new Deque();
console.log("\ndeque - staff adjusting line from both ends:");
staffDeque.addRear(patients[8]);
staffDeque.addRear(patients[6]);
staffDeque.addFront(patients[2]); // this patient got worse, bump to front
console.log("  front of line:", staffDeque.peekFront().toString());
console.log("  back of line:", staffDeque.peekRear().toString());
console.log("  removeFront (now being seen):", staffDeque.removeFront().toString());

// ---------------------------------------------------------
section("6. hashing - hash table, hash set, frequency count");
// ---------------------------------------------------------
const patientTable = new HashTable();
patients.forEach((p) => patientTable.set(p.id, p));

console.log("lookup id 106:", patientTable.get(106).toString());
patientTable.delete(102);
console.log("after deleting 102, has(102)?", patientTable.has(102));
console.log("bucket chain lengths (shows where collisions happened):");
console.log(patientTable.bucketReport().filter((b) => b.chainLength > 0));

const idSet = new HashSet();
patients.forEach((p) => idSet.add(p.id));
console.log("\nhash set - has(105)?", idSet.has(105), " has(999)?", idSet.has(999));

const departments = patients.map((p) => p.department);
const deptFreq = frequencyCount(departments);
console.log("\ndepartment frequency:", Object.fromEntries(deptFreq));
console.log("most requested department:", mostFrequent(departments).item);

// ---------------------------------------------------------
section("7. two-pointer and sliding window");
// ---------------------------------------------------------
const byAge = [...patients]
  .sort((a, b) => a.age - b.age)
  .map((p) => ({ id: p.id, value: p.age }));

console.log("patients sorted by age:", byAge.map((p) => `${p.id}:${p.value}`).join(", "));

const targetAgeSum = 100;
const pairResult = twoPointerFindPairWithSum(byAge, targetAgeSum);
if (pairResult.pair) {
  console.log(`two-pointer: found pair summing to ${targetAgeSum} -> ids ${pairResult.pair[0].id} & ${pairResult.pair[1].id} (${pairResult.steps} steps)`);
} else {
  console.log(`two-pointer: no pair found that sums to ${targetAgeSum}`);
}

// made up arrival counts per 10-min interval over 2 hours
const arrivalsPerInterval = [2, 1, 3, 5, 4, 1, 0, 6, 3, 2, 1, 4];
const k = 3; // looking for busiest 30-min stretch
const windowResult = maxArrivalsInWindow(arrivalsPerInterval, k);
console.log(`\nsliding window: busiest ${k} intervals in a row -> ${windowResult.maxSum} arrivals, starting at interval ${windowResult.startIndex}`);

section("done");
