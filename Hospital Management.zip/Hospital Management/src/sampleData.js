// sampleData.js
// dummy patient records so I don't have to type these out again in every file

const Patient = require("./Patient");

function getSamplePatients() {
  // made up 10 patients, tried to mix up priorities and departments a bit
  return [
    new Patient(105, "Ravi Kumar", 45, 1, 5, "Cardiology"),
    new Patient(102, "Anjali Sharma", 29, 3, 2, "General"),
    new Patient(110, "Mohit Verma", 62, 1, 12, "Cardiology"),
    new Patient(101, "Sara Khan", 34, 2, 1, "Orthopedics"),
    new Patient(108, "Farhan Ali", 8, 2, 9, "Pediatrics"),
    new Patient(103, "Neha Gupta", 71, 1, 3, "Neurology"),
    new Patient(107, "Vikram Singh", 50, 3, 7, "General"),
    new Patient(104, "Priya Nair", 25, 2, 4, "Orthopedics"),
    new Patient(109, "Aditya Rao", 39, 3, 10, "General"),
    new Patient(106, "Kavya Iyer", 55, 1, 6, "Cardiology"),
  ];
}

module.exports = { getSamplePatients };
