// patterns.js
// two-pointer technique and sliding window technique

// needs the array sorted already, by whatever "value" represents
// (e.g. age). finds a pair that adds up to targetSum
function twoPointerFindPairWithSum(sortedValues, targetSum) {
  let left = 0;
  let right = sortedValues.length - 1;
  let steps = 0;

  while (left < right) {
    steps++;
    const sum = sortedValues[left].value + sortedValues[right].value;

    if (sum === targetSum) {
      return { pair: [sortedValues[left], sortedValues[right]], steps };
    } else if (sum < targetSum) {
      left++; // sum too small, move left pointer up
    } else {
      right--; // sum too big, move right pointer down
    }
  }

  return { pair: null, steps }; // no pair found
}

// finds the k consecutive intervals with the highest total
// e.g. arrivalsPerInterval = arrivals every 10 min, k = 3 means
// "busiest 30 minute stretch"
function maxArrivalsInWindow(arrivalsPerInterval, k) {
  if (arrivalsPerInterval.length < k) {
    return { maxSum: null, startIndex: -1 };
  }

  // sum up the first window
  let windowSum = 0;
  for (let i = 0; i < k; i++) {
    windowSum += arrivalsPerInterval[i];
  }

  let maxSum = windowSum;
  let startIndex = 0;

  // slide the window forward one step at a time, just add the new
  // value and subtract the one that fell off - way faster than
  // recomputing the whole sum every time
  for (let i = k; i < arrivalsPerInterval.length; i++) {
    windowSum += arrivalsPerInterval[i] - arrivalsPerInterval[i - k];
    if (windowSum > maxSum) {
      maxSum = windowSum;
      startIndex = i - k + 1;
    }
  }

  return { maxSum, startIndex };
}

module.exports = { twoPointerFindPairWithSum, maxArrivalsInWindow };

/*
  two pointer - O(n) time, O(1) space, but only works if the array is
  already sorted. way better than the brute force way of checking every
  pair which would be O(n^2).

  sliding window - also O(n) time, O(1) space, for finding the best
  window of fixed size k. brute force here would be O(n*k) since you'd
  recompute the sum for every possible window from scratch.
*/
