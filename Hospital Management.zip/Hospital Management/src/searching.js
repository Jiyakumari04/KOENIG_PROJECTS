// searching.js
// linear search + binary search on patient id

// works on any array, sorted or not. just checks one by one
function linearSearchById(patients, targetId) {
  for (let i = 0; i < patients.length; i++) {
    if (patients[i].id === targetId) {
      return { patient: patients[i], comparisons: i + 1 };
    }
  }
  return { patient: null, comparisons: patients.length };
}

// NOTE: array has to be sorted by id first or this will give wrong results
function binarySearchById(patients, targetId) {
  let low = 0;
  let high = patients.length - 1;
  let comparisons = 0;

  while (low <= high) {
    comparisons++;
    const mid = Math.floor((low + high) / 2);

    if (patients[mid].id === targetId) {
      return { patient: patients[mid], comparisons };
    } else if (patients[mid].id < targetId) {
      low = mid + 1;
    } else {
      high = mid - 1;
    }
  }

  return { patient: null, comparisons };
}

module.exports = { linearSearchById, binarySearchById };

/*
  Linear search = O(n), doesn't care if data is sorted
  Binary search = O(log n) but needs sorted array first

  For the hospital: linear search is fine for a small unsorted list like
  "today's new patients". binary search would be used on the big master
  list once it's sorted by id, since it's way faster for large n.
  Downside of binary search is you have to keep the list sorted, which
  costs time whenever a patient is added/removed.
*/
