// Stack.js
// two versions of a stack - one using a regular array, one using linked nodes
// this is for the EMR undo feature (last action gets undone first = LIFO)

class ArrayStack {
  constructor() {
    this.items = [];
  }
  push(action) {
    this.items.push(action);
  }
  pop() {
    if (this.isEmpty()) return null;
    return this.items.pop();
  }
  peek() {
    if (this.isEmpty()) return null;
    return this.items[this.items.length - 1];
  }
  isEmpty() {
    return this.items.length === 0;
  }
  size() {
    return this.items.length;
  }
}

class StackNode {
  constructor(action) {
    this.action = action;
    this.next = null;
  }
}

class LinkedListStack {
  constructor() {
    this.top = null;
    this.count = 0;
  }
  push(action) {
    const node = new StackNode(action);
    node.next = this.top;
    this.top = node;
    this.count++;
  }
  pop() {
    if (this.isEmpty()) return null;
    const node = this.top;
    this.top = this.top.next;
    this.count--;
    return node.action;
  }
  peek() {
    if (this.isEmpty()) return null;
    return this.top.action;
  }
  isEmpty() {
    return this.top === null;
  }
  size() {
    return this.count;
  }
}

module.exports = { ArrayStack, LinkedListStack };

/*
  each "action" pushed is something like:
  { type: 'TRANSFER', patientId: 104, from: 'Orthopedics', to: 'Physiotherapy' }
  or { type: 'DELETE', patient: somePatientObj }
  to undo, you pop the last action and just reverse whatever it did.

  why a stack and not a queue - because the LAST thing done needs to be
  the FIRST thing undone (like ctrl+z). a queue would undo things in the
  wrong order (oldest first) which doesn't match how undo is supposed to
  work.

  push/pop/peek/isEmpty are all O(1) for both versions. space is O(n).

  array version is simpler and js arrays are already pretty fast for
  push/pop at the end. linked list version avoids any resizing overhead
  but uses a bit more memory per item because of the next pointer.
  honestly for this use case either works fine, array is probably good
  enough in practice.
*/
