// Queue.js
// normal queue, circular queue, and a deque

// ---------------- Queue (FIFO) ----------------
// using a linked list here instead of an array because array.shift()
// is O(n) every time (has to reindex the whole array) which is bad if
// we're dequeuing a lot. linked list keeps both ends O(1).

class QNode {
  constructor(patient) {
    this.patient = patient;
    this.next = null;
  }
}

class Queue {
  constructor() {
    this.front = null;
    this.rear = null;
    this.count = 0;
  }
  enqueue(patient) {
    const node = new QNode(patient);
    if (!this.front) {
      this.front = node;
      this.rear = node;
    } else {
      this.rear.next = node;
      this.rear = node;
    }
    this.count++;
  }
  dequeue() {
    if (this.isEmpty()) return null;
    const node = this.front;
    this.front = this.front.next;
    if (!this.front) this.rear = null; // queue is now empty
    this.count--;
    return node.patient;
  }
  peek() {
    return this.isEmpty() ? null : this.front.patient;
  }
  isEmpty() {
    return this.count === 0;
  }
  size() {
    return this.count;
  }
}

// ---------------- Circular Queue ----------------
// models a waiting room with a fixed number of chairs. when someone
// leaves, that chair slot gets reused right away instead of shifting
// everyone else down

class CircularQueue {
  constructor(capacity) {
    this.capacity = capacity;
    this.items = new Array(capacity).fill(null);
    this.frontIdx = 0;
    this.rearIdx = -1;
    this.count = 0;
  }
  isFull() {
    return this.count === this.capacity;
  }
  isEmpty() {
    return this.count === 0;
  }
  enqueue(patient) {
    if (this.isFull()) return false; // no chairs left
    this.rearIdx = (this.rearIdx + 1) % this.capacity;
    this.items[this.rearIdx] = patient;
    this.count++;
    return true;
  }
  dequeue() {
    if (this.isEmpty()) return null;
    const patient = this.items[this.frontIdx];
    this.items[this.frontIdx] = null;
    this.frontIdx = (this.frontIdx + 1) % this.capacity;
    this.count--;
    return patient;
  }
  peek() {
    return this.isEmpty() ? null : this.items[this.frontIdx];
  }
}

// ---------------- Deque ----------------
// can add/remove from front or back. used when staff need to bump
// someone to the front of the line or just add normally to the back

class Deque {
  constructor() {
    this.items = [];
  }
  addFront(patient) {
    this.items.unshift(patient);
  }
  addRear(patient) {
    this.items.push(patient);
  }
  removeFront() {
    return this.items.length ? this.items.shift() : null;
  }
  removeRear() {
    return this.items.length ? this.items.pop() : null;
  }
  peekFront() {
    return this.items.length ? this.items[0] : null;
  }
  peekRear() {
    return this.items.length ? this.items[this.items.length - 1] : null;
  }
  isEmpty() {
    return this.items.length === 0;
  }
  size() {
    return this.items.length;
  }
}

module.exports = { Queue, CircularQueue, Deque };

/*
  where these get used in the hospital:
  - Stack -> undo/redo in the EMR (see Stack.js)
  - Queue -> routine walk-in patients, first come first served
  - Circular Queue -> physical waiting room, fixed number of chairs
  - Deque -> nurse manager moving patients around at either end of the line
    (e.g. bump someone to front if they suddenly get worse)

  complexity:
  Queue (linked list version) - enqueue O(1), dequeue O(1)
  Circular Queue - enqueue/dequeue O(1), space is fixed at O(k)
  Deque (array based) - front/rear ops are roughly O(1) 
    (technically unshift/shift on arrays can be O(n) in the worst case
    in some engines but for a small waiting list this is fine)
*/
