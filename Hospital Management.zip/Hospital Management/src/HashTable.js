// HashTable.js
// building a hash map from scratch (using chaining for collisions)
// plus a hash set and a simple frequency counter

class HashTable {
  constructor(bucketCount = 16) {
    this.bucketCount = bucketCount;
    // each bucket is just an array, if two keys hash to the same
    // bucket they both just live in that array (this is "chaining")
    this.buckets = new Array(bucketCount).fill(null).map(() => []);
    this.size = 0;
  }

  _hash(key) {
    // nothing fancy, just a basic string hash (works for numbers too
    // since we stringify first)
    const str = String(key);
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      hash = (hash * 31 + str.charCodeAt(i)) % this.bucketCount;
    }
    return hash;
  }

  set(key, value) {
    const idx = this._hash(key);
    const bucket = this.buckets[idx];

    for (const pair of bucket) {
      if (pair.key === key) {
        pair.value = value; // key already exists, just update it
        return;
      }
    }
    bucket.push({ key, value });
    this.size++;
  }

  get(key) {
    const idx = this._hash(key);
    for (const pair of this.buckets[idx]) {
      if (pair.key === key) return pair.value;
    }
    return undefined;
  }

  has(key) {
    return this.get(key) !== undefined;
  }

  delete(key) {
    const idx = this._hash(key);
    const bucket = this.buckets[idx];
    for (let i = 0; i < bucket.length; i++) {
      if (bucket[i].key === key) {
        bucket.splice(i, 1);
        this.size--;
        return true;
      }
    }
    return false;
  }

  // just for checking how many collisions are happening per bucket
  bucketReport() {
    return this.buckets.map((b, i) => ({ bucket: i, chainLength: b.length }));
  }
}

// hash set = basically a hash table where we only care about the keys
class HashSet {
  constructor(bucketCount = 16) {
    this.table = new HashTable(bucketCount);
  }
  add(id) {
    this.table.set(id, true);
  }
  has(id) {
    return this.table.has(id);
  }
  remove(id) {
    return this.table.delete(id);
  }
  get size() {
    return this.table.size;
  }
}

// counts how many times each item shows up (e.g. department names)
function frequencyCount(items) {
  const freq = new Map();
  for (const item of items) {
    freq.set(item, (freq.get(item) || 0) + 1);
  }
  return freq;
}

function mostFrequent(items) {
  const freq = frequencyCount(items);
  let best = null;
  let bestCount = -1;
  for (const [key, count] of freq.entries()) {
    if (count > bestCount) {
      best = key;
      bestCount = count;
    }
  }
  return { item: best, count: bestCount, allCounts: freq };
}

module.exports = { HashTable, HashSet, frequencyCount, mostFrequent };

/*
  why hash table for fast patient lookup:
  average case O(1) for insert/search/delete, which beats binary search's
  O(log n), and unlike binary search the data doesn't need to stay sorted.
  this is nice since patients keep getting added and removed constantly.

  collision handling here is separate chaining - if two ids hash to the
  same bucket, we just append to that bucket's little array and search
  within it when needed. the other common approach is open addressing
  (probing for the next open slot) but that gets messy with deletions.

  worst case is still O(n) if everything happens to collide into one
  bucket, but with a decent hash function and enough buckets that
  shouldn't really happen in practice. space is O(n) overall.

  main limitation - no ordering. you can't ask "give me the patient with
  the next highest id after this one" efficiently like you could with a
  sorted array or a tree. also performance really does depend on having
  a good hash function, a bad one basically turns it back into a linked
  list situation.
*/
