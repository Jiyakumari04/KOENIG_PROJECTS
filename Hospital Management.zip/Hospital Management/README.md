# Lab 2 - Hospital ED Patient Management System

Prototype for the emergency department lab assignment. Covers searching,
sorting, linked lists, stacks, queues, hashing, and the two-pointer /
sliding-window patterns, all in plain JavaScript (no libraries).

## Running it

```
npm start
```
or just
```
node src/main.js
```

## Files

- `src/Patient.js` - patient object
- `src/sampleData.js` - fake patient data used everywhere else
- `src/searching.js` - linear + binary search
- `src/sorting.js` - bubble, selection, insertion, merge, quick sort
- `src/LinkedList.js` - singly + doubly linked list
- `src/Stack.js` - array stack + linked list stack (for undo)
- `src/Queue.js` - queue, circular queue, deque
- `src/HashTable.js` - hash table (chaining), hash set, frequency count
- `src/patterns.js` - two-pointer, sliding window
- `src/main.js` - runs all of the above so you can see the output

## Notes on why I picked what I picked

**Searching:** linear search works on anything but is O(n). binary search
is O(log n) but only works if the array's already sorted by id, so I used
that for the "master list" scenario and linear for smaller/unsorted lists.

**Sorting:** bubble/selection/insertion are all O(n^2) which is fine for
small lists but would be way too slow for thousands of records, so merge
sort and quick sort are there for the big-data case. merge sort is stable
so it keeps arrival order for patients with the same priority, quick sort
is usually faster in practice but not stable and has a bad O(n^2) worst
case.

**Array vs linked list:** arrays are faster to access by index but slow to
insert/delete in the middle (everything shifts). since patients get
added/removed all the time in an ED, a linked list avoids the shifting
cost. doubly linked list adds backward traversal too.

**Stack for undo:** last action needs to be undone first, that's just what
a stack (LIFO) does. did both an array version and linked-list version
since the lab asked for both.

**Queue / circular queue / deque:** normal queue for the fcfs routine
line, circular queue models a waiting room with a fixed number of chairs
(reuses a seat as soon as someone leaves instead of shifting everyone),
deque is for when staff need to add/remove from either end (like bumping
someone to the front if they get worse).

**Hash table:** built from scratch with chaining for collisions.
average O(1) lookup by patient id, way faster than binary search and
doesn't need the data sorted, which matters since ids get added/removed
constantly. hash set for tracking unique ids, plus a simple frequency
counter for figuring out which department gets used most.

**Two-pointer / sliding window:** two-pointer needs sorted data but finds
a matching pair in O(n) instead of checking every pair (O(n^2)). sliding
window finds the busiest stretch of k time intervals in O(n) by just
adding/removing one value each step instead of recalculating the whole
sum every time.

## complexity cheat sheet

| thing | time | space | notes |
|---|---|---|---|
| linear search | O(n) | O(1) | no sorting needed |
| binary search | O(log n) | O(1) | needs sorted array |
| bubble sort | O(n^2) | O(1) | stable |
| selection sort | O(n^2) | O(1) | not stable |
| insertion sort | O(n^2) | O(1) | stable, fast on nearly-sorted data |
| merge sort | O(n log n) | O(n) | stable |
| quick sort | O(n log n) avg, O(n^2) worst | O(log n) | not stable |
| linked list insert/delete (at known node) | O(1) | O(n) total | O(n) to find the node first |
| stack ops | O(1) | O(n) | |
| queue ops | O(1) | O(n) | |
| circular queue ops | O(1) | O(k) fixed | |
| hash table ops | O(1) avg, O(n) worst | O(n) | worst case = bad hash/collisions |
| two-pointer | O(n) | O(1) | needs sorted input |
| sliding window | O(n) | O(1) | fixed window size |
