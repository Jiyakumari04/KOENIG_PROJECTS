# CampusConnect

A student activity management portal built on the MERN stack (MongoDB, Express, React, Node.js). This is the Phase 2 deliverable: a full-stack app where the React front-end from Phase 1 is now backed by a real Express/MongoDB API — students and tasks are created, read, updated, and deleted through REST endpoints and persisted in the database.

## Project structure

```
campusconnect/
├── client/                        React front-end (Vite)
│   └── src/
│       ├── components/
│       │   ├── layout/            Header, NavBar, Footer, Layout shell
│       │   ├── common/            Button, Card, FormInput, Alert
│       │   └── dashboard/         StudentList, TaskBoard – CRUD UI backed by the API
│       ├── pages/                 Home, Login, Register, Dashboard, NotFound
│       ├── data/                  Mock announcement data (front-end only, no backend model)
│       ├── utils/
│       │   ├── validation.js      Client-side form validation
│       │   ├── api.js             Fetch wrapper for every backend call
│       │   └── auth.js            Remembers the logged-in student (localStorage)
│       ├── App.jsx, main.jsx, index.css
│       └── .env.example           VITE_API_BASE_URL
├── server/                        Node/Express + MongoDB API
│   ├── src/
│   │   ├── config/db.js           Mongoose connection
│   │   ├── models/                User.js, Task.js (schemas + validation)
│   │   ├── controllers/           userController.js, taskController.js (CRUD logic)
│   │   ├── routes/                userRoutes.js, taskRoutes.js
│   │   ├── middleware/            logger.js, errorHandler.js
│   │   ├── utils/asyncHandler.js
│   │   └── server.js              App entry point
│   └── .env.example               PORT, MONGODB_URI, CLIENT_URL
├── docs/                          Shared documentation
└── assets/                        Shared static assets (logos, icons, images)
```

## Getting started

### 1. Server

```bash
cd server
cp .env.example .env
# edit .env and set MONGODB_URI, e.g.:
#   mongodb://localhost:27017/campusconnect
#   or a MongoDB Atlas connection string
npm install
npm run dev
```

The API listens on `http://localhost:5000`. If `MONGODB_URI` isn't set or the database is unreachable, the server still starts (so `/api/health` responds) but every route that touches the database returns a clear `503` error until it's fixed.

### 2. Client

```bash
cd client
cp .env.example .env   # VITE_API_BASE_URL defaults to http://localhost:5000/api
npm install
npm run dev
```

The dev server runs at `http://localhost:5173`.

## API reference

| Method | Endpoint             | Description                          |
|--------|-----------------------|---------------------------------------|
| GET    | `/api/health`          | Service status check                  |
| POST   | `/api/users`           | Register a student                    |
| POST   | `/api/users/login`     | Authenticate a student                |
| GET    | `/api/users`           | List all students                     |
| GET    | `/api/users/:id`       | Get one student                       |
| PUT    | `/api/users/:id`       | Update a student's name/email/password|
| DELETE | `/api/users/:id`       | Delete a student                      |
| POST   | `/api/tasks`           | Create a task                         |
| GET    | `/api/tasks`           | List all tasks (with assigned student)|
| GET    | `/api/tasks/:id`       | Get one task                          |
| PUT    | `/api/tasks/:id`       | Update a task's details/status        |
| DELETE | `/api/tasks/:id`       | Delete a task                         |

Every response follows `{ success, data?, message?, errors? }`. Validation errors return `400` with a per-field `errors` map; a missing record returns `404`; a duplicate email returns `409`.

## What's implemented

- **Backend** – Express server with JSON body parsing, CORS, request logging, and centralized error handling. Mongoose models for `User` and `Task` with required-field, length, format, and uniqueness validation. Passwords are hashed with bcrypt and never returned in API responses.
- **Full CRUD** – both resources support create, read, update, and delete, backed directly by MongoDB.
- **Frontend integration**:
  - Registration and Login post to the real API and surface backend validation errors inline.
  - The Dashboard fetches students and tasks from MongoDB on load and after every change — no more mock data or `setTimeout`.
  - A "Registered students" panel supports inline edit and delete.
  - A "Tasks" panel supports creating a task (with an optional assignee), editing title/description/status/assignee, and deleting a task.
- **Responsive layout** – carried over from Phase 1, extended to the new data tables and forms.

## Known limitations

- Announcements remain front-end mock data — no `Announcement` model was requested for this lab, so that section is unchanged from Phase 1.
- Login is a plain email/password check against the hashed password in MongoDB; there's no session token/JWT, so the "logged-in" state is just remembered in the browser's `localStorage` for a friendlier Dashboard greeting and default task assignee. Add JWT-based auth as a follow-up if route protection is required.
