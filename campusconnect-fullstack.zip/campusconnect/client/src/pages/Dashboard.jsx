import { useCallback, useEffect, useState } from 'react';
import announcementsData from '../data/announcements.js';
import StudentList from '../components/dashboard/StudentList.jsx';
import TaskBoard from '../components/dashboard/TaskBoard.jsx';
import Alert from '../components/common/Alert.jsx';
import { fetchStudents, fetchTasks } from '../utils/api.js';
import { getCurrentUser } from '../utils/auth.js';

function Dashboard() {
  const currentUser = getCurrentUser();

  // Announcements stay as front-end mock data (no backend model in this lab).
  const [announcements, setAnnouncements] = useState([]);
  const [announcementsLoading, setAnnouncementsLoading] = useState(true);

  // TODO 12: Retrieve database records - students and tasks come from the API.
  const [students, setStudents] = useState([]);
  const [studentsLoading, setStudentsLoading] = useState(true);
  const [studentsError, setStudentsError] = useState('');

  const [tasks, setTasks] = useState([]);
  const [tasksLoading, setTasksLoading] = useState(true);
  const [tasksError, setTasksError] = useState('');

  const loadStudents = useCallback(async () => {
    setStudentsLoading(true);
    setStudentsError('');
    try {
      const data = await fetchStudents();
      setStudents(data);
    } catch (err) {
      setStudentsError(err.message || 'Could not load students.');
    } finally {
      setStudentsLoading(false);
    }
  }, []);

  const loadTasks = useCallback(async () => {
    setTasksLoading(true);
    setTasksError('');
    try {
      const data = await fetchTasks();
      setTasks(data);
    } catch (err) {
      setTasksError(err.message || 'Could not load tasks.');
    } finally {
      setTasksLoading(false);
    }
  }, []);

  useEffect(() => {
    const timer = window.setTimeout(() => {
      setAnnouncements(announcementsData);
      setAnnouncementsLoading(false);
    }, 500);

    loadStudents();
    loadTasks();

    return () => window.clearTimeout(timer);
  }, [loadStudents, loadTasks]);

  const openTasks = tasks.filter((t) => t.status !== 'completed').length;

  const stats = [
    { label: 'Announcements', value: announcements.length },
    { label: 'Registered students', value: students.length },
    { label: 'Open tasks', value: openTasks },
  ];

  return (
    <div>
      <div className="dash-header">
        <div className="dash-greeting">
          <h1 style={{ marginBottom: '0.2rem' }}>
            {currentUser ? `Welcome back, ${currentUser.name}` : 'Welcome back'}
          </h1>
          <p>Here's what's happening across campus this week.</p>
        </div>
      </div>

      <div className="stat-row">
        {stats.map((stat) => (
          <div className="stat" key={stat.label}>
            <span className="stat-num">{stat.value}</span>
            <span className="stat-label">{stat.label}</span>
          </div>
        ))}
      </div>

      <div className="section-title-row">
        <h2>Announcements</h2>
      </div>

      {announcementsLoading ? (
        <div className="loading-line">
          <span className="spinner" aria-hidden="true" />
          Loading announcements…
        </div>
      ) : announcements.length === 0 ? (
        <p>There are no announcements right now. Check back soon.</p>
      ) : (
        <div className="notice-board">
          {announcements.map((item) => (
            <article className="notice" key={item.id}>
              <div className="notice-meta">
                <span className="notice-tag">{item.tag}</span>
                <span>{item.date}</span>
              </div>
              <h3>{item.title}</h3>
              <p>{item.body}</p>
            </article>
          ))}
        </div>
      )}

      <div className="section-title-row dash-section">
        <h2>Registered students</h2>
      </div>
      <p>Live from MongoDB via GET /api/users.</p>
      <StudentList
        students={students}
        loading={studentsLoading}
        error={studentsError}
        onChanged={loadStudents}
      />

      <div className="section-title-row dash-section">
        <h2>Tasks</h2>
      </div>
      <p>Live from MongoDB via GET /api/tasks. Add, edit, or remove a task below.</p>
      <TaskBoard
        tasks={tasks}
        students={students}
        loading={tasksLoading}
        error={tasksError}
        onChanged={loadTasks}
      />
    </div>
  );
}

export default Dashboard;
