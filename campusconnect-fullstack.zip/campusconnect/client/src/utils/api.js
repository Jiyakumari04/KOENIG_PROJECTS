/**
 * Thin fetch wrapper shared by every page that talks to the Express API.
 * Centralizes the base URL, JSON headers, and error handling so pages only
 * deal with plain JS objects and thrown Errors with a user-facing message.
 */
const BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:5000/api';

async function request(path, options = {}) {
  let response;
  try {
    response = await fetch(`${BASE_URL}${path}`, {
      headers: { 'Content-Type': 'application/json' },
      ...options,
    });
  } catch (networkErr) {
    throw new Error('Could not reach the server. Is the backend running?');
  }

  const isJson = response.headers.get('content-type')?.includes('application/json');
  const body = isJson ? await response.json() : null;

  if (!response.ok || body?.success === false) {
    const message = body?.message || `Request failed with status ${response.status}.`;
    const error = new Error(message);
    error.fieldErrors = body?.errors;
    throw error;
  }

  return body?.data;
}

const get = (path) => request(path, { method: 'GET' });
const post = (path, data) => request(path, { method: 'POST', body: JSON.stringify(data) });
const put = (path, data) => request(path, { method: 'PUT', body: JSON.stringify(data) });
const del = (path) => request(path, { method: 'DELETE' });

// --- Students (Users) ---
export const registerStudent = (data) => post('/users', data);
export const loginStudent = (data) => post('/users/login', data);
export const fetchStudents = () => get('/users');
export const updateStudent = (id, data) => put(`/users/${id}`, data);
export const deleteStudent = (id) => del(`/users/${id}`);

// --- Tasks ---
export const fetchTasks = () => get('/tasks');
export const createTask = (data) => post('/tasks', data);
export const updateTask = (id, data) => put(`/tasks/${id}`, data);
export const deleteTask = (id) => del(`/tasks/${id}`);
