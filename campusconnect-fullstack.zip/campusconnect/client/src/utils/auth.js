/**
 * Minimal "who's logged in" helper. The lab doesn't call for full session/JWT
 * auth, but the Dashboard needs to know the current student to greet them
 * and to pre-select them when creating a task. We just remember the last
 * successful login in localStorage, keyed by this app.
 */
const STORAGE_KEY = 'campusconnect.currentUser';

export function setCurrentUser(user) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(user));
}

export function getCurrentUser() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

export function clearCurrentUser() {
  localStorage.removeItem(STORAGE_KEY);
}
