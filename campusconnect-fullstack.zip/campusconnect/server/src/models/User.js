import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';

const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

/**
 * TODO 7 / TODO 8: Users collection + Mongoose model.
 * Fields: name, email, password, registrationDate (as suggested in the lab guide).
 * Validation: required fields, data-type/format checks, length limits, and a
 * unique constraint on email.
 */
const userSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, 'Name is required.'],
    trim: true,
    minlength: [2, 'Name must be at least 2 characters.'],
    maxlength: [80, 'Name cannot exceed 80 characters.'],
  },
  email: {
    type: String,
    required: [true, 'Email is required.'],
    trim: true,
    lowercase: true,
    unique: true,
    match: [EMAIL_PATTERN, 'Enter a valid email address.'],
  },
  password: {
    type: String,
    required: [true, 'Password is required.'],
    minlength: [8, 'Password must be at least 8 characters.'],
    select: false, // never returned by default queries
  },
  registrationDate: {
    type: Date,
    default: Date.now,
  },
});

// Hash the password whenever it's set/changed, before saving.
userSchema.pre('save', async function hashPassword(next) {
  if (!this.isModified('password')) return next();
  try {
    const salt = await bcrypt.genSalt(10);
    this.password = await bcrypt.hash(this.password, salt);
    next();
  } catch (err) {
    next(err);
  }
});

// Instance method used by the login endpoint.
userSchema.methods.comparePassword = function comparePassword(candidate) {
  return bcrypt.compare(candidate, this.password);
};

// Never leak the password hash or __v when a document is serialized to JSON.
userSchema.set('toJSON', {
  transform: (_doc, ret) => {
    delete ret.password;
    delete ret.__v;
    return ret;
  },
});

const User = mongoose.model('User', userSchema);

export default User;
