import mongoose from 'mongoose';

/**
 * TODO 7 / TODO 8: Tasks collection + Mongoose model.
 * Fields: title, description, status, assignedUser, createdDate (as
 * suggested in the lab guide). `assignedUser` references the Users
 * collection so tasks can be populated with the student they belong to.
 */
const taskSchema = new mongoose.Schema({
  title: {
    type: String,
    required: [true, 'Task title is required.'],
    trim: true,
    minlength: [3, 'Title must be at least 3 characters.'],
    maxlength: [120, 'Title cannot exceed 120 characters.'],
  },
  description: {
    type: String,
    trim: true,
    maxlength: [500, 'Description cannot exceed 500 characters.'],
    default: '',
  },
  status: {
    type: String,
    enum: {
      values: ['pending', 'in-progress', 'completed'],
      message: 'Status must be one of: pending, in-progress, completed.',
    },
    default: 'pending',
  },
  assignedUser: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    default: null,
  },
  createdDate: {
    type: Date,
    default: Date.now,
  },
});

taskSchema.set('toJSON', {
  transform: (_doc, ret) => {
    delete ret.__v;
    return ret;
  },
});

const Task = mongoose.model('Task', taskSchema);

export default Task;
