/**
 * Wraps an async route/controller so any rejected promise is forwarded to
 * Express's error-handling middleware instead of crashing the process.
 * Usage: router.get('/', asyncHandler(getUsers));
 */
function asyncHandler(fn) {
  return function wrapped(req, res, next) {
    Promise.resolve(fn(req, res, next)).catch(next);
  };
}

export default asyncHandler;
