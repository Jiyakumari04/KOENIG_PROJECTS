import User from '../models/User.js';

/**
 * TODO 9: Implement CRUD Operations - User Management.
 * Every handler talks to MongoDB directly through the User model and
 * responds with the shared { success, data, message } shape.
 */

// POST /api/users  (also used by the Register form)
export async function createUser(req, res) {
  const { name, email, password } = req.body;

  const user = await User.create({ name, email, password });

  res.status(201).json({
    success: true,
    message: 'Student registered successfully.',
    data: user,
  });
}

// POST /api/users/login
export async function loginUser(req, res) {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({
      success: false,
      message: 'Email and password are required.',
    });
  }

  // password has `select: false` on the schema, so it must be opted back in.
  const user = await User.findOne({ email: email.toLowerCase().trim() }).select('+password');

  if (!user || !(await user.comparePassword(password))) {
    return res.status(401).json({
      success: false,
      message: 'Invalid email or password.',
    });
  }

  res.json({
    success: true,
    message: `Welcome back, ${user.name}.`,
    data: user, // toJSON transform strips the password hash
  });
}

// GET /api/users
export async function getUsers(req, res) {
  const users = await User.find().sort({ registrationDate: -1 });
  res.json({ success: true, data: users });
}

// GET /api/users/:id
export async function getUserById(req, res) {
  const user = await User.findById(req.params.id);
  if (!user) {
    return res.status(404).json({ success: false, message: 'Student not found.' });
  }
  res.json({ success: true, data: user });
}

// PUT /api/users/:id
export async function updateUser(req, res) {
  const { name, email, password } = req.body;
  const user = await User.findById(req.params.id);

  if (!user) {
    return res.status(404).json({ success: false, message: 'Student not found.' });
  }

  if (name !== undefined) user.name = name;
  if (email !== undefined) user.email = email;
  if (password) user.password = password; // triggers the pre-save hash hook

  await user.save();

  res.json({
    success: true,
    message: 'Student record updated.',
    data: user,
  });
}

// DELETE /api/users/:id
export async function deleteUser(req, res) {
  const user = await User.findByIdAndDelete(req.params.id);
  if (!user) {
    return res.status(404).json({ success: false, message: 'Student not found.' });
  }
  res.json({ success: true, message: 'Student record deleted.', data: { id: req.params.id } });
}
