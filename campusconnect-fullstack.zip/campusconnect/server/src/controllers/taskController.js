import Task from '../models/Task.js';

/**
 * TODO 9: Implement CRUD Operations - Task Management.
 * `assignedUser` is populated with the student's name/email so the React
 * dashboard can render it without a second round trip.
 */
const ASSIGNED_USER_FIELDS = 'name email';

// POST /api/tasks
export async function createTask(req, res) {
  const { title, description, status, assignedUser } = req.body;

  const task = await Task.create({
    title,
    description,
    status,
    assignedUser: assignedUser || null,
  });
  await task.populate('assignedUser', ASSIGNED_USER_FIELDS);

  res.status(201).json({
    success: true,
    message: 'Task created successfully.',
    data: task,
  });
}

// GET /api/tasks
export async function getTasks(req, res) {
  const tasks = await Task.find()
    .sort({ createdDate: -1 })
    .populate('assignedUser', ASSIGNED_USER_FIELDS);
  res.json({ success: true, data: tasks });
}

// GET /api/tasks/:id
export async function getTaskById(req, res) {
  const task = await Task.findById(req.params.id).populate('assignedUser', ASSIGNED_USER_FIELDS);
  if (!task) {
    return res.status(404).json({ success: false, message: 'Task not found.' });
  }
  res.json({ success: true, data: task });
}

// PUT /api/tasks/:id
export async function updateTask(req, res) {
  const { title, description, status, assignedUser } = req.body;
  const task = await Task.findById(req.params.id);

  if (!task) {
    return res.status(404).json({ success: false, message: 'Task not found.' });
  }

  if (title !== undefined) task.title = title;
  if (description !== undefined) task.description = description;
  if (status !== undefined) task.status = status;
  if (assignedUser !== undefined) task.assignedUser = assignedUser || null;

  await task.save();
  await task.populate('assignedUser', ASSIGNED_USER_FIELDS);

  res.json({
    success: true,
    message: 'Task updated successfully.',
    data: task,
  });
}

// DELETE /api/tasks/:id
export async function deleteTask(req, res) {
  const task = await Task.findByIdAndDelete(req.params.id);
  if (!task) {
    return res.status(404).json({ success: false, message: 'Task not found.' });
  }
  res.json({ success: true, message: 'Task deleted successfully.', data: { id: req.params.id } });
}
