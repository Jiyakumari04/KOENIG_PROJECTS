import { Router } from 'express';
import asyncHandler from '../utils/asyncHandler.js';
import {
  createTask,
  getTasks,
  getTaskById,
  updateTask,
  deleteTask,
} from '../controllers/taskController.js';

/**
 * TODO 3: Design REST API Structure - Task resource.
 *   POST   /api/tasks       Create task
 *   GET    /api/tasks       View all tasks
 *   GET    /api/tasks/:id   View one task
 *   PUT    /api/tasks/:id   Update task status/details
 *   DELETE /api/tasks/:id   Delete task
 */
const router = Router();

router.route('/').post(asyncHandler(createTask)).get(asyncHandler(getTasks));
router
  .route('/:id')
  .get(asyncHandler(getTaskById))
  .put(asyncHandler(updateTask))
  .delete(asyncHandler(deleteTask));

export default router;
