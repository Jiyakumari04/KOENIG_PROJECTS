import { Router } from 'express';
import asyncHandler from '../utils/asyncHandler.js';
import {
  createUser,
  loginUser,
  getUsers,
  getUserById,
  updateUser,
  deleteUser,
} from '../controllers/userController.js';

/**
 * TODO 3: Design REST API Structure - Student/User resource.
 *   POST   /api/users         Create student record (Register form)
 *   POST   /api/users/login   Authenticate a student (Login form)
 *   GET    /api/users         View all student records
 *   GET    /api/users/:id     View one student record
 *   PUT    /api/users/:id     Update student information
 *   DELETE /api/users/:id     Delete student record
 */
const router = Router();

router.post('/login', asyncHandler(loginUser));
router.route('/').post(asyncHandler(createUser)).get(asyncHandler(getUsers));
router
  .route('/:id')
  .get(asyncHandler(getUserById))
  .put(asyncHandler(updateUser))
  .delete(asyncHandler(deleteUser));

export default router;
