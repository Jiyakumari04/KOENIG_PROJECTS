/**
 * TODO 2: Configure Middleware - request logging.
 * Logs method, path, status code, and response time for every request.
 * Runs before the routes so it can time the full request lifecycle.
 */
function requestLogger(req, res, next) {
  const start = process.hrtime.bigint();

  res.on('finish', () => {
    const durationMs = Number(process.hrtime.bigint() - start) / 1e6;
    const timestamp = new Date().toISOString();
    console.log(
      `[${timestamp}] ${req.method} ${req.originalUrl} -> ${res.statusCode} (${durationMs.toFixed(1)}ms)`
    );
  });

  next();
}

export default requestLogger;
