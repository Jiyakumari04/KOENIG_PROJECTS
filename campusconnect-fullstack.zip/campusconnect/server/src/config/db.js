import mongoose from 'mongoose';

/**
 * TODO 6: Configure MongoDB Connection
 * -------------------------------------
 * Opens a single Mongoose connection using MONGODB_URI from the environment.
 * The server is intentionally kept alive even if this fails on startup, so
 * that GET /api/health still responds while the URI/service is fixed; every
 * route that touches the database will simply return a clear 503 error
 * (see middleware/errorHandler.js) until the connection succeeds.
 */
export async function connectDB() {
  const uri = process.env.MONGODB_URI;

  if (!uri) {
    console.warn(
      '[db] MONGODB_URI is not set. Copy server/.env.example to server/.env ' +
        'and fill it in, then restart the server.'
    );
    return false;
  }

  try {
    mongoose.set('strictQuery', true);
    const conn = await mongoose.connect(uri);
    console.log(`[db] MongoDB connected -> ${conn.connection.host}/${conn.connection.name}`);

    mongoose.connection.on('error', (err) => {
      console.error('[db] MongoDB connection error:', err.message);
    });
    mongoose.connection.on('disconnected', () => {
      console.warn('[db] MongoDB disconnected');
    });

    return true;
  } catch (err) {
    console.error('[db] Failed to connect to MongoDB:', err.message);
    return false;
  }
}

/** True once Mongoose has an open connection (readyState 1). */
export function isDbConnected() {
  return mongoose.connection.readyState === 1;
}

export default connectDB;
